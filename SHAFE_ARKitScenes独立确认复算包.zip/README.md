# SHAFE ARKitScenes statistical replay

The archive contains the locked visit roster, ZIP range receipts and frame hashes in the screening records, the local and fresh official-source geometry replay receipts, saved SHAFE scores, model-pair gaps, all primary and sensitivity summaries, the registered supplementary and cross-metric contrasts, and the independent statistical verifier. It also archives the acquisition and scoring source files referenced by the frozen record.

The verifier uses Python 3.11 and NumPy 2.4.6. From the extracted archive root, run the following command.

```sh
python shafe_public_optical/verify_confirmation_statistics.py shafe_public_optical/arkitscenes_temporal_confirmation --secondary --metrics --online
```

The verifier recomputes the sample roster, checks the saved screening and reconstruction records, rebuilds the pairwise reversal flags, and reproduces the paired intervals and exact primary p value. It also replays the alignment, single-interpolation and cross-metric statistics. Rebuilding the input pixels and regenerating SR images requires the ARKitScenes file members listed in the acquisition receipts and external model weights. The archive starts from the screening records and saved scores for that reason.
