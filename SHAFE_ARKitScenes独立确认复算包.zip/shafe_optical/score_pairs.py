"""Score marker-verified pairs with the existing four SR models and protocols."""

import argparse
from pathlib import Path
import sys

import cv2
import numpy as np
from PIL import Image

from marker_geometry import ROI_EDGE_POINTS, project


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'shafe_ranking'))

from ranking_common import MODELS, atomic_json, file_sha, load
from dev_pipeline import luminance, project as downproject, read, save
from ranking_models import artifact, pending_outputs, run_vosr, stamp, torch_outputs
from ranking_scores import Scorer, apply, crop
from registration import candidate, direct_candidate
from robust_controls import gray8, lucas_kanade


def read_pairs(paths):
    pairs = []
    for path in paths:
        info = load(path / 'geometry.json')
        lr = path / 'lr.png'
        hr = path / 'hr.png'
        pair = dict(pair=str(path), geometry=info, geometry_sha256=file_sha(path / 'geometry.json'))
        if info['status'] == 'pass':
            hashes = dict(lr=file_sha(lr), hr=file_sha(hr))
            if hashes != info['crop_sha256']:
                raise ValueError(f'Crop has changed since marker validation in {path}')
            pair.update(scene=hashes['lr'], lr=str(lr), lr_sha256=hashes['lr'],
                        hr=str(hr), hr_sha256=hashes['hr'])
        pairs.append(pair)
    return pairs


def infer(pairs, output):
    config = file_sha(HERE.parent / 'shafe_ranking/formal_lock.json')
    rows = list({pair['scene']: pair for pair in pairs if 'scene' in pair}.values())
    for model in MODELS:
        pending = list(pending_outputs(rows, output, model, config))
        if not pending:
            continue
        print(model, len(pending), 'unique LR inputs', flush=True)
        if model == 'VOSR':
            run_vosr(pending, output, config)
        elif model == 'Bicubic':
            for row, path in pending:
                with Image.open(row['lr']) as lr:
                    save(path, np.asarray(lr.convert('RGB').resize((512, 512), Image.Resampling.BICUBIC)))
                stamp(path, row, config)
        else:
            torch_outputs(model, pending, config)


def warp_reference(hr, matrix):
    inverse_coordinates = project(np.linalg.inv(matrix), ROI_EDGE_POINTS)
    if np.any(inverse_coordinates < 2) or np.any(inverse_coordinates >= 510):
        raise ValueError('Warp leaves the common scoring ROI unsupported')
    aligned = cv2.warpPerspective(hr.astype(np.float32), matrix, (512, 512),
                                  flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT)
    return crop(aligned)


def score_pair(pair, output, scorer):
    lr, hr = read(pair['lr']), read(pair['hr'])
    if lr.shape != (128, 128, 3) or hr.shape != (512, 512, 3):
        raise ValueError('Unexpected crop dimensions')
    geometry = pair['geometry']
    whole = candidate(hr, lr)
    lk, tracks = lucas_kanade(gray8(luminance(lr)), gray8(downproject(luminance(hr))))
    actions = dict(fixed=[0., 0.], global_lr=whole['vector'] if whole['executable'] else [0., 0.],
                   lk_lr=lk, marker_translation=geometry['hr_correction_xy'])
    refs = {name: crop(apply(hr, vector)) for name, vector in actions.items()}
    refs['marker_projective'] = warp_reference(hr, np.asarray(geometry['hr_to_lr_hr_transform']))
    refs['marker_holdout'] = warp_reference(hr, np.asarray(geometry['hr_to_lr_hr_transform_holdout']))
    results = {}
    for model in MODELS:
        sr_path = artifact(output, model, pair['scene'])
        sr = read(sr_path)
        direct = direct_candidate(hr, sr)
        sr_crop = crop(sr)
        model_refs = dict(refs, direct=crop(apply(hr, direct)))
        scores = scorer.evaluate([(sr_crop, reference) for reference in model_refs.values()])
        results[model] = dict(actions=dict(actions, direct=direct), scores=dict(zip(model_refs, scores, strict=True)),
                              sr_sha256=file_sha(sr_path))
    return dict(pair, models=results, lk_tracks=tracks)


def run(paths, output):
    cv2.setNumThreads(1)
    pairs = read_pairs(paths)
    infer(pairs, output)
    scorer = Scorer() if any('scene' in pair for pair in pairs) else None
    results = []
    for pair in pairs:
        if 'scene' in pair:
            pair = score_pair(pair, output, scorer)
            print('Scored', pair['pair'], flush=True)
        results.append(pair)
    atomic_json(output / 'scores.json', results)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('pairs', type=Path, nargs='+')
    args = parser.parse_args()
    run(args.pairs, args.output)
