# SHAFE 模型排序确认试验

主终点、分层分析、数据集平均排名和核验范围见 [实验结果](RESULTS.md)。

`formal_lock.json` 是运行前冻结的协议。`inputs/manifest.json` 记录 144 个 COCO 场景的图源、许可编号、文件与像素哈希、裁片和干预。`formal/scores/` 含全部场景、对齐动作、四种超分方法和四个评分指标的逐例结果。`formal/analysis.json` 保存主终点、总体排序及敏感性分析。`formal/verification.json` 保存独立统计核验和预抽取六场景的评分复算。`source_replay/verification.json` 记录从源图重建 144 组输入及对事先抽定六场景重跑四种超分方法的像素校验。

`camera_ranking/` 包含 32 个 RealSR 相机场景的锁、原始清单、逐例评分、分析和独立核验。RealSR 重用前期已登记的场景，单独报告。零注入的主要统计量是直接对齐和 LR-LK 得到相反排序的比例。已知注入条件用撤销人工加入的 HR 平移后得到的发布几何作为参照。

## 复算统计

使用 Python 3.11 和 NumPy 2.4.6，在解压目录运行 `python recompute_statistics.py`。脚本校验归档完整性及两份冻结方案的摘要，再复算 COCO 和 RealSR 的统计并与归档数值比对。可用 `--output PATH` 将两组复算结果保存到单独的 JSON。

首次统计在生成结果前因 Python 元组不支持一元负号而退出。运行入口 `run_frozen_analysis.py` 在调用原函数前将并列阈值转换为 NumPy 数组，保持阈值数值、评分记录、估计方法及冻结文件原样。解压后的复算使用相同入口。

## 从像素复跑

保留输入、推理、评分、核验的原始代码与历史文件路径，供对照本机运行环境和复查实现。`ranking_models.py formal`、`ranking_scores.py formal`、`run_frozen_analysis.py`、`verify_ranking.py formal` 是本机运行顺序。`score_shard.py` 调用同一个冻结评分函数并把完整场景记录写入正式目录。`source_replay.py` 在单独目录重建输入和重新推理。运行环境和权重哈希见锁文件。

本包可从逐场景得分复算整套统计。像素级流程需要 COCO 和 RealSR 源图、超分方法与指标所需的外部权重，以及锁中记录的本机代码与依赖环境。COCO 的六场景复算使用原始输出重建评分裁片，并重新计算全部 PSNR、SSIM 及主终点所涉部分 SHAFE、ST-LPIPS 得分。RealSR 的本机入口为 `python camera_ranking_audit.py`，核验入口为 `python verify_camera_ranking.py`。
