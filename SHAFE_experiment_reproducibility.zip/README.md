# SHAFE 逐例结果与复现

本包收录正式试验、恢复模型替换、DIV2K 隔离集、COCO 确认试验和 RealSR 相机注入试验，附带配准基线、平滑形变和模型排序补测。包含逐例动作、SHAFE 分数、冻结方案、统计核验脚本、原图来源和实现快照。已知注入的统计和验收可独立运行。RealSR 零注入图像的自然错位另需独立地标参照，真实地标答卷尚未收集。地标盲评使用单独发给评审的 `RealSR_landmark_review.zip`。本包含盲评别名映射和方法动作，供实验组织者使用。

## 从逐例结果复算

完整解压，进入解压目录。使用 Python 3.11+ 及 NumPy。

```text
python -m pip install numpy
python recompute.py results/formal_cases.csv --external results/external_cases.csv --transfer results/transfer_cases.csv
python experiment_audit/verify_frozen_replay.py .
python experiment_audit/verify_holdout.py experiment_audit/holdout
python experiment_audit/verify_confirmation.py experiment_audit --pixel-replay
python experiment_audit/verify_registration_extensions.py experiment_audit --pixel-replay
python experiment_audit/pixel_metric_audit.py verify
python experiment_audit/rank_audit.py results/formal_cases.csv results/transfer_cases.csv rank_recomputed.json
python external/landmark_review/analysis_smoke.py
```

- `recompute.py` 独立重算强退化 80% 工作点、配对区间、固定阈值动作计数、SHAFE 误差和相机注入响应。原正式试验、外域试验和模型替换分别见 `results/`。原版复现说明为 `README_formal.md`。
- `verify_frozen_replay.py` 核对正式对照及 RealSR 全局注入的全量源图和评分复跑记录。它通过零注入 SR 像素哈希连接两次复跑，验证冻结输入指纹、各组评分图对数、逐项最大分差，并将归档动作与分数同统计用 CSV 逐例对照。另核验四个场景连续运行源图到评分的抽查记录。
- `verify_holdout.py` 核验 DIV2K 的 2,304 个条件、三个冻结几何终点和 26 个 SHAFE 分层。读取 `experiment_audit/holdout/synthetic/`。
- `verify_confirmation.py` 复算 COCO 的 864 个条件、1,790 个不同评分图对及按场景配对区间，检查坐标方向、像素哈希的配对一致性和 SHAFE 对照。还核验 288 个羽化条件记录及 128 个 RealSR 条件记录。`--pixel-replay` 额外核验 COCO 确认试验的全量像素复跑记录。
- `verify_registration_extensions.py` 核验同一批 COCO 和 RealSR 上的补充配准基线，以及 1,152 个 COCO、256 个 RealSR 平滑形变条件。检查已知逆向量、LR 和 SR 哈希、评分复用和配对区间。`--pixel-replay` 另外检查全量像素回放记录与归档的场景覆盖、图对数、逐场景最大分差及输入指纹。模型排序复算结果可与 `experiment_audit/rank_results.json` 比较。
- `pixel_metric_audit.py verify` 核对 PSNR、SSIM 与 SHAFE 的 352 个场景条件、归档评分图对哈希、PSNR 的像素平方误差和三种指标的配对区间。
- `analysis_smoke.py` 用人工生成的坐标运行原方法和稳健方法两条地标分析，检查输入校验和动作判定。测试中的标注仅用于联调。

## 文件索引

| 实验 | 逐例输入与结果 | 方案及分析 |
| --- | --- | --- |
| 原双侧／单侧及 Real-ESRGAN 替换 | `results/*_cases.csv`、`results/*_batch_inputs.json` | `provenance/formal_lock.json`、`provenance/transfer_plan.json`、`results/*_evaluation.json` |
| VOSR 正式对照及 RealSR 全局注入的像素复跑 | `formal/` 和 `external/` 下的 `batch_inputs.json`、`geometry.json`、`decisions.json`、`scores.json` | `experiment_audit/frozen_full_pixel_replay.json` |
| 从源图重新生成全部正式和 RealSR VOSR 图像 | 300 个正式输入、32 个 RealSR 输入 | `experiment_audit/full_vosr_replay.json` |
| 从源图重新生成 VOSR 图像并验分的抽查 | 两个合成场景的两种退化、两台 RealSR 相机各一个场景 | `experiment_audit/source_replay.json` |
| DIV2K | `experiment_audit/holdout/synthetic/{geometry,scores}.json` | `experiment_audit/holdout/lock.json`、`experiment_audit/holdout/synthetic/full_analysis.json` |
| DIV2K 稳健性补充 | `experiment_audit/holdout/robust_controls/results.json` | 同目录的 `lock.json` |
| COCO | `experiment_audit/coco_confirm/{batch_inputs,geometry,scores}.json` | 同目录的 `lock.json`、`full_analysis.json`、`examples/`。全量像素复跑见 `experiment_audit/coco_confirmation_pixel_replay.json` |
| COCO 羽化与 RealSR 补充 | `experiment_audit/coco_confirm/sensitivity/*_analysis.json` | 同目录的 `lock.json`、`experiment_audit/holdout/camera_local/` |
| 补充配准基线 | `experiment_audit/registration_benchmarks/{coco,realsr}_results.json` | 同目录的 `lock.json` |
| 平滑形变 | `experiment_audit/{local_deformation,camera_deformation}/results.json` | 各目录的 `lock.json` 与 COCO 的初版锁。初次尝试在生成结果前修正了坐标数组类型。全量像素回放记录在 `experiment_audit/deformation_full_pixel_replay.json` |
| VOSR 与 Real-ESRGAN 的 SHAFE 排序 | `experiment_audit/rank_results.json` | `rank_audit.py` 及报告中的阈值、对照和输入哈希 |
| PSNR、SSIM 和 SHAFE 同像素对照 | `experiment_audit/pixel_metric_results.json` | `pixel_metric_plan.json`、`pixel_metric_replay.json` |
| RealSR 自然残余错位 | 待导入两份真实评审 JSON | `external/landmark_review/` 下的两份锁和 `分析计划.md` |

记录的 `hr_added`、`sr_added` 以 HR 像素为单位，正方向为向右、向下。 `actions` 是方法实际施加给 HR 的向量。 `oracle` 只撤销已知的人为 HR 平移。 `simple_lr`、`tile_mean`、`tile_trimmed`、`median_lk` 分别为全图 LR、分块均值、分块截尾和 Lucas–Kanade 中位数。 `scores` 是各方法动作下的 SHAFE 值。RealSR 注入分析的 `incremental_error` 用该方法相对自身零注入动作的变化计算。

## 接收真实地标答卷后

将两份相互独立的完整导出作为输入，分别得到原方法和稳健方法结果。

```text
python external/landmark_review/landmark_analysis.py score review_a.json review_b.json landmark_results.json
python external/landmark_review/robust_landmark_analysis.py score review_a.json review_b.json robust_landmark_results.json
```

两个脚本会检查归档哈希、答卷所属批次和评审身份重复。盲评标注用于估计自然的基线偏移。注入条件在这一估计上加已知位移，分析仍逐条件报告。

## 从图像重新运行

上述复算命令使用归档的逐例结果。从像素重新计算几何或运行 VOSR、Real-ESRGAN 和 SHAFE，需要另行取得该批次的原始图像、图像裁片和模型权重，并配置设备与原路径映射。归档保留原始方案字节和哈希。迁移时可另建运行副本，在该副本中进行路径映射及重新锁定，将其作为一次新运行。

- `frozen_implementation/` 保存正式试验模块，`archived_wrappers/` 保存调用的上游包装脚本。后续图像级脚本保存在 `experiment_audit/`，其导入依赖正式模块。镜像原工作区结构时，将正式模块和 `provenance/` 中对应的设计、开发、校准记录放回各自原目录。
- 数据下载地址、裁片和像素校验值见各轮 `batch_inputs.json`、`experiment_audit/holdout_source.json`、`provenance/data/` 和 `provenance/external/`。COCO 的原始索引也随包附带。RealSR 的相机局部条件需要 `external/batch_inputs.json` 中指出的图像。
- `environment_verified.json` 保存原运行的版本、GPU 和 VOSR、SHAFE 权重哈希。Real-ESRGAN 的权重哈希见 `provenance/transfer_plan.json`。
- 原始完整数据集、运行中间图、生成图缓存和预训练权重需单独取得。例图及来源/许可随包保存于 `experiment_audit/coco_confirm/examples/`。
- 在原实验环境内，`python experiment_audit/replay_frozen.py fresh_frozen_replay.json` 从归档 LR、HR 和 VOSR 输出重算正式对照和 RealSR 全局注入的配准、门控、评分像素与 SHAFE。以场景和退化组为单位保存检查点，可用同一输出路径续跑。该命令使用已有 VOSR 输出，SHAFE 比对容差为 10⁻⁵，门控置信分容差为 10⁻⁶。
- 在同一环境及原图路径可用时，`python experiment_audit/replay_all_vosr.py full_vosr_run` 重建全部 332 组 LR、HR，校对原始文件及新裁片的 SHA-256，并重新推理 VOSR。逐像素比对 VOSR 原始 RGB 输出及正式几何零注入版本。程序将核验记录按批写入 `full_vosr_run/full_vosr_replay.json`，同一目录可续跑。
- 在同一环境及原图路径可用时，`python experiment_audit/replay_from_source.py fresh_source_replay` 从源图重建样本，在新目录重新运行 VOSR、配准和 SHAFE。每个合成数据集或相机按场景编号取中间一例，两种合成退化均纳入。脚本对照归档的输入 SHA-256 和 VOSR 输出像素，并使用全量复跑的配准和评分验收逻辑。
- 在原实验目录结构、冻结路径和 Python 环境均可用时，`python experiment_audit/replay_coco_confirmation.py new_coco_replay.json` 从像素重新生成 COCO 确认试验的动作、评分输入和 SHAFE 分数。用新输出路径从头复跑，已有输出路径则继续对应的检查点。
- 在同一环境下，`python experiment_audit/replay_warp_cohorts.py` 重新计算平滑形变像素、动作及 SHAFE 分数。要从头运行补充回放，请先在运行副本中移走 `experiment_audit/deformation_full_pixel_replay.json`。两个先期像素抽查记录和对应逐例结果随包保留。两类复跑的评分误差容差均为 10⁻⁶。
- 在同一环境下，`python experiment_audit/pixel_metric_audit.py replay` 将已归档的动作应用到原评分像素，并用独立的 OpenCV 高斯滤波实现重算 SSIM。要求像素哈希与平方误差一致，SSIM 分差小于 10⁻¹²。

数据与上游实现链接见 `README_formal.md`。 [COCO](https://cocodataset.org/#download) · [Real-ESRGAN](https://github.com/xinntao/Real-ESRGAN)
