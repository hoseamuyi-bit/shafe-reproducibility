# Reproducing the results

This archive contains de-identified case results for 2,400 synthetic evaluations and 128 camera evaluations, a portable table check, archived estimates and the frozen implementation. Each scene is one resampling unit. The condition rows are repeated measurements.

## Recompute from cases

Use Python 3.11+ with NumPy.

```text
python -m pip install numpy
python recompute.py results/formal_cases.csv --external results/external_cases.csv
```

This recomputes the strong-degradation 80% comparison, the paired scene bootstrap, fixed-threshold action counts and the SHAFE mean absolute errors. It independently implements the threshold crossing on integer event counts. Compare its output to `results/independent_checks.json`, `results/formal_evaluation.json` and the two SHAFE analysis files. Bootstrap draws with insufficient candidate recall are omitted from the percentile calculation and counted separately.

## Case fields

- `scene`, `group`, `dataset`, `degradation`, and `condition` identify a case.
- `hr_added_*` and `sr_added_*` are the injected global shifts in HR pixels. Right and down are positive. The SR local warp and HR local replacement are named by condition and do not appear as global shifts.
- `*_fit_*` reports the two LR-registration fits. `candidate_correct` marks an executable shared HR action that reverses the known shift within the prespecified tolerance.
- `raw`, `direct`, `simple_lr`, `single`, `dual`, `legacy`, and `oracle` prefixes give each method's applied HR translation and SHAFE score. The `oracle` undoes the known HR injection on the disturbed image. The `clean_hr_shafe` field uses the original unshifted HR, where comparable.
- Confidence is blank when the shared candidate is unavailable or inside the hold band. A zero action includes both rejected proposals and cases with no executable proposal.
- For camera cases, injections are known relative to the published, prealigned pairs. Absolute natural HR/SR alignment is unverified. `external_response.json` records the agreement of action changes with the added shift, relative to each scene's zero-injection case.

## Image-level implementation

`provenance/formal_lock.json` records the prespecified analysis, inputs, thresholds and hashes. The provenance and batch-input records use paths from the original run. The code in `frozen_implementation/` is the exact archival snapshot. Re-running image inference on another machine requires remapping and rehashing local paths and supplying the separately obtained source data, archival SHAFE/VOSR wrappers and model weights. Generated images, pretrained model weights and source dataset images are omitted from this archive. The case-level reproduction above has no dependency on those assets.

Data and upstream implementations

- DIV2K validation source [ETH Zürich release](https://data.vision.ee.ethz.ch/cvl/DIV2K/).
- Urban100 HR source [SelfExSR repository](https://github.com/jbhuang0604/SelfExSR/tree/8f6dd8c1d20cb7e8792a7177b4f6fd677633f598/data/Urban100/image_SRF_4).
- RealSR V3 release and acquisition pipeline [RealSR repository](https://github.com/csjcai/RealSR).
- VOSR one-step model [upstream repository](https://github.com/Visual-AI/VAIsr).
- SHAFE metric [HalluGen repository](https://github.com/edshkim98/HalluGen/tree/924c40b0b2718cef9d7e079aaf56a7df85679490).
