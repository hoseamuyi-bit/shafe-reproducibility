"""Evaluate fixed-LR attribution with synthetic and CameraSR injection controls."""

import argparse
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

import cv2
import numpy as np
import torch


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sys.path.insert(0, str(WORK / "shafe_pilot"))

from lr_anchor import Degradation, Registration, Thresholds, calibrate, classify, degrade_to_lr, register_to_lr, shift_hr
from run_attribution import CALIBRATION_IDS, DIRECTIONS, MAGNITUDES, SCORE_MARGIN, SEARCH_RADIUS, direct_correction, local_change
from run_shafe import CONFIGURATIONS, DEFAULT_WEIGHT, image, load_metric, provenance, sha256, tensor, write_results


MAX_INJECTION = max(MAGNITUDES)
ZERO = (0, 0)
CAMERA_SIGMA = 2.0
CONFIRM = WORK / "day67" / "confirm_set"
SYNTHETIC_SR = WORK / "day67" / "confirm_runs" / "seed42" / "fp32"
CAMERA = WORK / "day45" / "camerasr"
PILOT_FIT = WORK / "shafe_pilot" / "results" / "shafe_attribution_vosr_calibrated.json"
PRIMARY = {"aligned", "hr", "sr"}
LABELS = {"reference_shift": "hr", "restoration_shift": "sr", "both_shift": "both", "shared_shift": "shared"}
METHODS = ("raw", "direct", "simple_lr", "proposed", "oracle")
SCORE_CROP = np.s_[SCORE_MARGIN:-SCORE_MARGIN, SCORE_MARGIN:-SCORE_MARGIN]


@dataclass(frozen=True)
class Scene:
    id: str
    stratum: str
    hr: np.ndarray
    lr: np.ndarray
    sr: np.ndarray
    roi: tuple[int, int, int, int]
    forward: Degradation | None


@dataclass(frozen=True)
class Variant:
    condition: str
    shift_px: int
    expected: str
    hr: np.ndarray
    sr: np.ndarray
    lr: np.ndarray
    hr_added: tuple[int, int] = ZERO
    sr_added: tuple[int, int] = ZERO


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def roll_shift(shift, factor):
    return (shift[0] * factor, shift[1] * factor)


def synthetic_scenes(cohort):
    manifest = read_json(CONFIRM / "manifest.json")
    for pair in manifest["pairs"]:
        row = next(item for item in pair["items"] if item["arm"] == "a")
        hr, observed = image(CONFIRM / row["gt"]), image(CONFIRM / row["lq"])
        forward = Degradation(blur_sigma_hr=pair["degradation"]["blur_sigma_hr"])
        if cohort == "synthetic_exact":
            lr = degrade_to_lr(hr, observed.shape[::-1], forward)[:, :, 0].copy()
            sr = hr
        else:
            lr, sr = observed, image(SYNTHETIC_SR / "images" / Path(row["gt"]).name)
        yield Scene(pair["pair_id"], pair["condition"], hr, lr, sr, tuple(pair["roi_hr_xyxy_exclusive"]), forward)


def camera_scene(case):
    hr, lr, sr = case.load()
    h, w = hr.shape
    return Scene(case.scene_id, "city100_nikon", hr, lr, sr, (w // 4, h // 4, 3 * w // 4, 3 * h // 4), None)


def camera_fit(moving, lr):
    """Match low-pass luminance on the archived CameraSR grid with a fixed passband."""
    pad = SCORE_MARGIN
    r = SEARCH_RADIUS
    source = cv2.GaussianBlur(moving.astype(np.float32), (13, 13), CAMERA_SIGMA, borderType=cv2.BORDER_REFLECT_101)
    anchor = cv2.GaussianBlur(lr.astype(np.float32), (13, 13), CAMERA_SIGMA, borderType=cv2.BORDER_REFLECT_101)
    crop = anchor[pad:-pad, pad:-pad]
    search = source[pad - r:-(pad - r), pad - r:-(pad - r)]
    approximate_sse = cv2.matchTemplate(search, crop, cv2.TM_SQDIFF)
    # Recheck all near ties in double precision. Subtracting large sums in
    # matchTemplate can blur the distinction between neighboring shifts.
    tolerance = 2e-6 * crop.size * 255**2
    second = np.partition(approximate_sse.ravel(), 1)[1]
    best_candidates = np.argwhere(approximate_sse <= second + tolerance)
    ranked = []
    h, w = crop.shape
    for y, x in best_candidates:
        dy, dx = int(r - y), int(r - x)
        difference = search[y:y + h, x:x + w].astype(np.float64) - crop
        rmse = float(np.sqrt(np.mean(difference**2)))
        ranked.append((rmse, dx**2 + dy**2, dx, dy))
    (value, _, dx, dy), (next_value, _, ndx, ndy) = sorted(ranked)[:2]
    return Registration((dx, dy), (ndx, ndy), value, next_value, next_value - value,
                        max(abs(dx), abs(dy)) == r, (pad, pad, pad + w, pad + h))


def fit(scene, img, lr):
    if scene.forward is None:
        return camera_fit(img, lr)
    return register_to_lr(img, lr, max_shift=SEARCH_RADIUS, input_border_hr=MAX_INJECTION, degradation=scene.forward)


def variants(scene, direction, exact):
    hr, sr, lr = scene.hr, scene.sr, scene.lr
    yield Variant("aligned", 0, "aligned", hr, sr, lr)
    for size in MAGNITUDES:
        delta = roll_shift(direction, size)
        reverse = roll_shift(delta, -1)
        moved_hr, moved_sr = shift_hr(hr, *reverse), shift_hr(sr, *delta)
        yield Variant("hr", size, "hr", moved_hr, sr, lr, hr_added=reverse)
        yield Variant("sr", size, "sr", hr, moved_sr, lr, sr_added=delta)
    yield Variant("both", MAX_INJECTION, "both", moved_hr, moved_sr, lr, reverse, delta)
    yield Variant("shared", MAX_INJECTION, "shared", shift_hr(hr, *delta), moved_sr, lr, delta, delta)
    yield Variant("local", MAX_INJECTION, "aligned", hr, local_change(sr, scene.roi, delta), lr)
    if exact:
        changed_anchor = degrade_to_lr(moved_hr, lr.shape[::-1], scene.forward)[:, :, 0].copy()
        # The intentionally substituted anchor makes zero global motion relative to moved_hr.
        yield Variant("anchor_swap", MAX_INJECTION, "sr", moved_hr, sr, changed_anchor)


def camera_thresholds(cases):
    scenes = [camera_scene(case) for case in cases]
    controls = [[], []]
    for index, scene in enumerate(scenes):
        u = DIRECTIONS[index % len(DIRECTIONS)]
        moves = [ZERO, *(roll_shift(u, sign * size) for size in MAGNITUDES for sign in (-1, 1))]
        unrelated = scenes[(index + 1) % len(scenes)].lr
        for arm, moving in enumerate((scene.hr, scene.sr)):
            for offset in moves:
                controls[arm].append((fit(scene, shift_hr(moving, *offset), scene.lr), roll_shift(offset, -1)))
            controls[arm].append((fit(scene, moving, unrelated), None))
    flat = np.full_like(scenes[0].lr, 128)
    flat_fit = camera_fit(flat, flat)
    for arm_controls in controls:
        arm_controls.append((flat_fit, None))
    return tuple(calibrate(arm_controls) for arm_controls in controls)


def frozen_thresholds():
    frozen = read_json(PILOT_FIT)
    if frozen["calibration_probe_ids"] != list(CALIBRATION_IDS):
        raise ValueError("Archived threshold calibration IDs do not match the frozen pilot split")
    return Thresholds(**frozen["thresholds"]), Thresholds(**frozen["vosr_sr_thresholds"])


def paper_scores(metric, pairs, device, batch_size):
    scores = []
    lowpass = metric._apply_lowpass_batched
    paper = CONFIGURATIONS["paper_shafe"]

    def paper_lowpass(images, cutoff_radius):
        return lowpass(images, cutoff_radius=paper["radius"])

    with (
        torch.inference_mode(),
        patch.object(metric, "_apply_lowpass_batched", side_effect=paper_lowpass),
        patch.object(metric.eth_feature, "temperature", paper["temperature"]),
    ):
        for start in range(0, len(pairs), batch_size):
            predictions, references = zip(*pairs[start:start + batch_size])
            scores.extend(metric(tensor(predictions).to(device), tensor(references).to(device)).tolist())
    if not np.isfinite(scores).all():
        raise ValueError("SHAFE returned a nonfinite score")
    return scores


def evaluate_scene(scene, direction, cohort, threshold_sets, metric, device, batch_size):
    pending, rows, fits, pair_ids = [], [], {}, {}

    def estimate(img, anchor):
        key = (id(img), id(anchor))
        if key not in fits:
            fits[key] = fit(scene, img, anchor)
        return fits[key]

    def score_id(reference, restored, correction):
        pred = restored[SCORE_CROP]
        ref = (reference if correction == ZERO else shift_hr(reference, *correction))[SCORE_CROP]
        signature = hashlib.sha256(pred.tobytes() + ref.tobytes()).digest()
        if signature not in pair_ids:
            pair_ids[signature] = len(pending)
            pending.append((pred, ref))
        return pair_ids[signature]

    hr_base = estimate(scene.hr, scene.lr)
    sr_base = estimate(scene.sr, scene.lr)
    cases = list(variants(scene, direction, cohort == "synthetic_exact"))
    for case in cases:
        hr = estimate(case.hr, case.lr)
        sr = estimate(case.sr, case.lr)
        direct = direct_correction(case.hr, case.sr)
        oracle = roll_shift(case.hr_added, -1)
        for mode, (hr_limits, sr_limits) in threshold_sets.items():
            attribution = classify(hr, sr, hr_limits, sr_thresholds=sr_limits)
            predicted = LABELS.get(attribution.label, attribution.label)
            applied = hr.shift if predicted == "hr" else ZERO
            corrections = (ZERO, direct, hr.shift, applied, oracle)
            indices = tuple(score_id(case.hr, case.sr, correction) for correction in corrections)
            rows.append(({
                "cohort": cohort, "calibration_mode": mode, "scene_id": scene.id, "stratum": scene.stratum,
                "condition": case.condition, "shift_px": case.shift_px, "expected": case.expected,
                "prediction": predicted, "correction_applied": applied != ZERO,
                "simple_lr_correction_applied": hr.shift != ZERO, "direct_correction_applied": direct != ZERO,
                "hr_correction_exact": case.condition == "hr" and applied == oracle,
                "hr_baseline_dx": hr_base.shift[0], "hr_baseline_dy": hr_base.shift[1],
                "sr_baseline_dx": sr_base.shift[0], "sr_baseline_dy": sr_base.shift[1],
                "hr_added_dxdy": case.hr_added, "sr_added_dxdy": case.sr_added,
                "hr_fit_dxdy": hr.shift, "sr_fit_dxdy": sr.shift,
                "direct_applied_dxdy": direct, "proposed_applied_dxdy": applied,
                "oracle_applied_dxdy": oracle, "hr_fit_status": attribution.hr_status,
                "sr_fit_status": attribution.sr_status, "hr_rmse": hr.rmse, "sr_rmse": sr.rmse,
                "hr_margin": hr.margin, "sr_margin": sr.margin,
            }, indices))
    scores = paper_scores(metric, pending, device, batch_size)
    result = [dict(row, **{f"shafe_{method}": scores[idx] for method, idx in zip(METHODS, indices)})
              for row, indices in rows]
    if cohort == "synthetic_exact":
        pure = next(row for row in result if row["condition"] == "hr" and row["shift_px"] == MAX_INJECTION)
        swapped = next(row for row in result if row["condition"] == "anchor_swap")
        if pure["shafe_raw"] != swapped["shafe_raw"]:
            raise AssertionError("Anchor swap altered the unchanged SHAFE input pair")
    return result


def low_texture_checks(cohort, mode, threshold_sets):
    size = 493 if cohort == "camera" else 512
    shape = (493, 493) if cohort == "camera" else (128, 128)
    cases = []
    for origin in (96, 160):
        flat = np.full((size, size), origin, dtype=np.uint8)
        lr = np.full(shape, origin, dtype=np.uint8)
        forward = None if cohort == "camera" else Degradation()
        scene = Scene("flat", "constant", flat, lr, flat, (0, 0, size, size), forward)
        matched = fit(scene, flat, lr)
        hr_limits, sr_limits = threshold_sets
        result = classify(matched, matched, hr_limits, sr_thresholds=sr_limits)
        cases.append({"cohort": cohort, "calibration_mode": mode, "intensity": origin,
                      "prediction": result.label, "hr_fit_status": result.hr_status, "sr_fit_status": result.sr_status})
    return cases


def protocol():
    from camera_inputs import camera_cases

    confirm = read_json(CONFIRM / "manifest.json")
    camera = camera_cases()
    return {
        "protocol": "Fixed LR attribution and selective HR correction, integer global translation",
        "synthetic_scene_ids": [row["pair_id"] for row in confirm["pairs"]], "synthetic_arm": "a",
        "camera_calibration_ids": [case.scene_id for case in camera if case.split == "calibration"],
        "camera_test_ids": [case.scene_id for case in camera if case.split == "test"],
        "pilot_calibration_ids": CALIBRATION_IDS, "pilot_thresholds_sha256": sha256(PILOT_FIT),
        "manifest_sha256": {"synthetic": sha256(CONFIRM / "manifest.json"),
                            "camera": sha256(CAMERA / "dataset" / "manifest.json")},
        "magnitudes_hr_px": MAGNITUDES, "direction_cycle_dxdy": DIRECTIONS,
        "search_radius_hr_px": SEARCH_RADIUS, "score_margin_hr_px": SCORE_MARGIN,
        "main_conditions": sorted(PRIMARY), "supplementary_conditions": ["both", "shared", "local", "anchor_swap", "constant"],
        "camera_targets": {"macro_recall": 0.85, "max_false_hr_correction_rate": 0.05,
                           "shafe_mae_vs_direct": "lower", "shafe_mae_vs_simple_lr": "incremental benefit"},
        "synthetic_exact": "Nominal per-scene isotropic blur and 4x Pillow bicubic LR generated from HR. SR equals HR before injection.",
        "synthetic_vosr": "Archived real model output and input. Registration uses nominal blur plus downsampling, without modeling local haze or noise.",
        "camera": "Released CameraSR Nikon City100 paired images were pre-registered; archived 493x493 evaluation grid. Fixed symmetric Gaussian smoothing with sigma 2, and luminance RMSE. Frozen transfer and separate camera-calibrated modes.",
        "label_scope": "Camera and VOSR labels identify the added perturbation, irrespective of residual baseline shifts. All scenes are counted.",
        "oracle": "Undo only known HR injection on the fixed common scored crop. On anchor swap no HR correction is expected.",
        "local": "Translate only SR inside a preregistered ROI, with 12-pixel cosine feather. Synthetic target ROI; camera central half-width and half-height.",
    }


def run(args):
    cv2.setNumThreads(1)
    args.out.mkdir(parents=True, exist_ok=True)
    locked = args.out / "protocol.json"
    serialized = json.dumps(protocol(), ensure_ascii=False, indent=2) + "\n"
    if locked.exists() and locked.read_text(encoding="utf-8") != serialized:
        raise ValueError("The saved protocol differs. Use a separate output directory for a changed study.")
    locked.write_text(serialized, encoding="utf-8")
    if args.lock_only:
        return

    frozen = frozen_thresholds()
    if args.cohort == "camera":
        from camera_inputs import camera_cases

        cases = camera_cases()
        camera_cal = camera_thresholds([case for case in cases if case.split == "calibration"])
        thresholds = {"frozen": frozen, "camera_calibrated": camera_cal}
        scenes = (camera_scene(case) for case in cases if case.split == "test")
    else:
        thresholds = {"frozen": frozen if args.cohort == "synthetic_vosr" else (frozen[0], frozen[0])}
        scenes = synthetic_scenes(args.cohort)
    print(f"{args.cohort} thresholds: {thresholds}", flush=True)

    metric = load_metric(args.weight, args.threads).to(args.device)
    metric.device = args.device
    metric.eth_feature.device = args.device
    metric.eth_feature.model.to(args.device)
    low_texture = [row for mode, limits in thresholds.items() for row in low_texture_checks(args.cohort, mode, limits)]
    rows = []
    for index, scene in enumerate(scenes):
        if args.limit is not None and index >= args.limit:
            break
        rows.extend(evaluate_scene(scene, DIRECTIONS[index % len(DIRECTIONS)], args.cohort, thresholds,
                                   metric, args.device, args.batch_size))
        print(f"{args.cohort}: {index + 1} scenes complete ({scene.id}, {len(rows)} case rows)", flush=True)

    details = provenance(metric)
    details["device"] = args.device
    details["configurations"] = {"paper_shafe": CONFIGURATIONS["paper_shafe"]}
    name = args.cohort if args.limit is None else f"smoke_{args.cohort}"
    write_results(args.out, name, rows, {
        "protocol_sha256": sha256(locked), "provenance": details, "case_rows": len(rows),
        "thresholds": {mode: {arm: asdict(limit) for arm, limit in zip(("hr", "sr"), values)}
                       for mode, values in thresholds.items()}, "low_texture": low_texture,
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", choices=("synthetic_exact", "synthetic_vosr", "camera"), default="synthetic_exact")
    parser.add_argument("--out", type=Path, default=HERE / "results")
    parser.add_argument("--weight", type=Path, default=DEFAULT_WEIGHT)
    parser.add_argument("--threads", type=int, default=3)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--limit", type=int, help="Smoke-test subset; outputs use a separate filename")
    parser.add_argument("--lock-only", action="store_true")
    arguments = parser.parse_args()
    if min(arguments.threads, arguments.batch_size, arguments.limit or 1) <= 0 or arguments.limit == 0:
        parser.error("threads, batch size, and limit must be positive")
    run(arguments)
