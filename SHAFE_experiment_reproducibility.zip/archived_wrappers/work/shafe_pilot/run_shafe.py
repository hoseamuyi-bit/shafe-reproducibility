"""Run the pinned HalluGen SHAFE implementation on our existing probe pairs."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
from statistics import median
from unittest.mock import patch

import numpy as np
import timm
import torch
from PIL import Image
from safetensors.torch import load_file

from SHAFE import SHAFE


HERE = Path(__file__).resolve().parent
PROBES = HERE.parent / "paired_probes" / "pilot"
PREDICTIONS = HERE.parent / "vosr" / "results" / "probes_fp32" / "images"
SOURCE_COMMIT = "924c40b0b2718cef9d7e079aaf56a7df85679490"
SOURCE_SHA = "88075de02c7b61e5a86c7a6845dad12fbdad801d2ccaaabefdc3dab8b6a5835c"
WEIGHT_REVISION = "1879d4e9cca4208d175f4b8edaa779f64a439e4a"
WEIGHT_SHA = "9f972048b90eb41857f46c286a3394e0097b3225e3319941206e94100d6b356b"
MODEL_NAME = "resnetaa50d.d_in12k"
FULL_WEIGHT = HERE / f"{MODEL_NAME}.safetensors"
FEATURE_WEIGHT = HERE / f"{MODEL_NAME}.features.safetensors"
DEFAULT_WEIGHT = FULL_WEIGHT if FULL_WEIGHT.is_file() else FEATURE_WEIGHT
CONFIGURATIONS = {
    "paper_shafe": {"radius": 50, "temperature": 0.01, "feature_indices": [1, 2]},
    "repo_shafe": {"radius": 60, "temperature": 0.02, "feature_indices": [1, 2]},
}


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load_metric(weight, threads):
    if sha256(HERE / "SHAFE.py") != SOURCE_SHA:
        raise ValueError("The local SHAFE.py differs from the pinned HalluGen implementation")
    weight_digest = sha256(weight)
    if weight_digest == WEIGHT_SHA:
        scope = "full checkpoint"
    else:
        weight_manifest = json.loads((HERE / "weight_ranges.json").read_text(encoding="utf-8"))
        if weight_digest != weight_manifest["features_sha256"] or weight_manifest["revision"] != WEIGHT_REVISION:
            raise ValueError(f"Unrecognized weight snapshot: {weight_digest}")
        scope = "published weights for conv1, bn1, layer1, layer2"
    torch.set_num_threads(threads)
    create_model = timm.create_model

    def pinned_weights(name, **kwargs):
        if name != MODEL_NAME or not kwargs.get("pretrained"):
            raise ValueError(f"Unexpected feature extractor configuration: {name}, {kwargs}")
        if weight_digest == WEIGHT_SHA:
            return create_model(name, pretrained_cfg_overlay={"file": str(weight)}, **kwargs)
        model = create_model(name, **{**kwargs, "pretrained": False})
        model.load_state_dict(load_file(str(weight)), strict=True)
        return model

    # The model architecture and preprocessing are the original implementation.
    # Redirect only its pretrained weight loader to the verified local snapshot.
    with patch.object(timm, "create_model", side_effect=pinned_weights):
        metric = SHAFE(device="cpu").eval()
    metric.weight_provenance = {"file": weight.name, "scope": scope, "sha256": weight_digest}
    return metric


def image(path):
    with Image.open(path) as source:
        return np.array(source.convert("L"))


def tensor(images):
    return torch.from_numpy(np.stack(images)).unsqueeze(1).float().div_(255)


@torch.inference_mode()
def score(metric, pairs, batch_size=4):
    """Score (prediction, reference) grayscale uint8 pairs of the same size."""
    results = []
    for index in range(0, len(pairs), batch_size):
        predictions, references = zip(*pairs[index:index + batch_size])
        predictions = tensor(predictions)
        references = tensor(references)
        repo_scores = metric(predictions, references).tolist()
        lowpass = metric._apply_lowpass_batched

        def paper_lowpass(images, cutoff_radius):
            return lowpass(images, cutoff_radius=CONFIGURATIONS["paper_shafe"]["radius"])

        with (
            patch.object(metric, "_apply_lowpass_batched", side_effect=paper_lowpass),
            patch.object(metric.eth_feature, "temperature", CONFIGURATIONS["paper_shafe"]["temperature"]),
        ):
            paper_scores = metric(predictions, references).tolist()
        results.extend(
            {"paper_shafe": paper, "repo_shafe": repo}
            for paper, repo in zip(paper_scores, repo_scores)
        )
    if any(not np.isfinite(value) for row in results for value in row.values()):
        raise ValueError("SHAFE returned a non-finite score")
    return results


def provenance(metric):
    return {
        "source_commit": SOURCE_COMMIT,
        "source_sha256": SOURCE_SHA,
        "weight_revision": WEIGHT_REVISION,
        "weight": metric.weight_provenance,
        "published_full_checkpoint_sha256": WEIGHT_SHA,
        "backbone": MODEL_NAME,
        "configurations": CONFIGURATIONS,
        "input": "Pillow RGB to 8-bit luminance, float32 divided by 255, single channel",
        "device": "cpu",
        "threads": torch.get_num_threads(),
        "torch": torch.__version__,
        "timm": timm.__version__,
        "probe_manifest_sha256": hashlib.sha256((PROBES / "manifest.json").read_bytes()).hexdigest(),
    }


def write_results(out, name, rows, summary):
    out.mkdir(parents=True, exist_ok=True)
    with (out / f"{name}.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (out / f"{name}.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )


def run_baseline(metric, out):
    probes = json.loads((PROBES / "manifest.json").read_text(encoding="utf-8"))["pairs"]
    rows = []
    samples = []
    for probe in probes:
        first, second = probe["items"]
        reference = image(PROBES / first["gt"])
        changed = image(PROBES / second["gt"])
        prediction = image(PREDICTIONS / Path(first["gt"]).name)
        comparisons = {
            "identity": reference,
            "known_structure_change" if first["label"] != second["label"] else "same_label_change": changed,
            "vosr_vs_reference": prediction,
        }
        for condition, comparison in comparisons.items():
            rows.append({
                "pair_id": probe["pair_id"],
                "split": probe["split"],
                "target": probe["target"],
                "visibility": probe["visibility"],
                "condition": condition,
            })
            samples.append((comparison, reference))

    for row, scores in zip(rows, score(metric, samples)):
        row.update(scores)
    summary = {"provenance": provenance(metric), "dataset": "local paired probes, 512 x 512", "conditions": {}}
    for condition in ("identity", "known_structure_change", "same_label_change", "vosr_vs_reference"):
        scores = [row for row in rows if row["condition"] == condition]
        summary["conditions"][condition] = {"n": len(scores)}
        for config in CONFIGURATIONS:
            values = [row[config] for row in scores]
            summary["conditions"][condition][config] = {
                "min": min(values), "median": median(values), "max": max(values)
            }
    for config in CONFIGURATIONS:
        assert summary["conditions"]["identity"][config]["max"] < 1e-5
        assert summary["conditions"]["known_structure_change"][config]["median"] > 1e-4
    write_results(out, "shafe_baseline", rows, summary)
    print(json.dumps(summary["conditions"], indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--weight", type=Path, default=DEFAULT_WEIGHT)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--out", type=Path, default=HERE / "results")
    args = parser.parse_args()
    run_baseline(load_metric(args.weight.resolve(), args.threads), args.out)


if __name__ == "__main__":
    main()
