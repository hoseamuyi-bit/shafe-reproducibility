"""Evaluate whether a fixed low-resolution image identifies the shifted side."""

import argparse
from dataclasses import asdict
import json
from pathlib import Path
from statistics import median

import cv2
import numpy as np
from PIL import Image, ImageFilter

from lr_anchor import Degradation, calibrate, classify, degrade_to_lr, register_to_lr, shift_hr
from run_shafe import DEFAULT_WEIGHT, HERE, PREDICTIONS, PROBES, image, load_metric, provenance, score, write_results


SEARCH_RADIUS = 8
INJECTED_RADIUS = 6
SCORE_MARGIN = 20
MAGNITUDES = (2, 6)
DIRECTIONS = ((1, 0), (0, 1), (-1, 0), (0, -1))
CALIBRATION_IDS = tuple(f"cal{i:02}" for i in range(1, 5))
TEST_IDS = tuple(f"test{i:02}" for i in range(9, 21))
LABELS = {
    "clean": "aligned",
    "hr_shift": "reference_shift",
    "sr_shift": "restoration_shift",
    "local_sr_shift": "aligned",
    "local_sr_blur": "aligned",
    "anchor_swapped": "restoration_shift",
}


def grayscale(data):
    return np.asarray(Image.fromarray(data).convert("L"))


def translated(image, dx, dy):
    return grayscale(shift_hr(image, dx, dy))


def direct_correction(reference, prediction):
    """Register HR directly to SR with an integer shift and normalized correlation."""
    radius = SEARCH_RADIUS
    inner = reference[SCORE_MARGIN:-SCORE_MARGIN, SCORE_MARGIN:-SCORE_MARGIN]
    start = SCORE_MARGIN - radius
    search = prediction[start:-start, start:-start]
    corr = cv2.matchTemplate(search, inner, cv2.TM_CCOEFF_NORMED)
    _, _, _, (x, y) = cv2.minMaxLoc(corr)
    return x - radius, y - radius


def local_change(source, box, displacement=None):
    x0, y0, x1, y1 = box
    if displacement is None:
        alternate = np.asarray(Image.fromarray(source).filter(ImageFilter.GaussianBlur(3)))
    else:
        alternate = translated(source, *displacement)
    patch = source[y0:y1, x0:x1].astype(np.float32)
    modified = alternate[y0:y1, x0:x1].astype(np.float32)
    ys, xs = np.indices(patch.shape)
    edge_distance = np.minimum(np.minimum(xs, x1 - x0 - 1 - xs), np.minimum(ys, y1 - y0 - 1 - ys))
    weight = 0.5 - 0.5 * np.cos(np.pi * np.minimum(edge_distance / 12, 1))
    result = source.copy()
    result[y0:y1, x0:x1] = np.rint((1 - weight) * patch + weight * modified).astype(np.uint8)
    return result


def probe_images(probe):
    first = probe["items"][0]
    gt = image(PROBES / first["gt"])
    lr = image(PROBES / first["lq"])
    sr = image(PREDICTIONS / Path(first["gt"]).name)
    degradation = Degradation(blur_sigma_hr=probe["degradation"]["blur_sigma_hr"])
    if probe["degradation"]["haze_retained"] != 1:
        raise ValueError("This pilot expects a shift-invariant degradation without local haze")
    return gt, lr, sr, degradation


def register(moving, lr, degradation):
    return register_to_lr(
        moving, lr, max_shift=SEARCH_RADIUS, degradation=degradation, input_border_hr=INJECTED_RADIUS
    )


def calibration_thresholds(probes):
    controls = []
    for index, key in enumerate(CALIBRATION_IDS):
        gt, observed_lr, _, degradation = probe_images(probes[key])
        expected_lr = degrade_to_lr(gt, observed_lr.shape[::-1], degradation)
        ux, uy = DIRECTIONS[index]
        shifts = [(0, 0)] + [(sign * n * ux, sign * n * uy) for n in MAGNITUDES for sign in (-1, 1)]
        for dx, dy in shifts:
            moving = translated(gt, dx, dy)
            for lr in (expected_lr, observed_lr):
                controls.append((register(moving, lr, degradation), (-dx, -dy)))
    # A uniform image has no coordinate evidence in the valid central crop.
    constant = np.full((512, 512), 128, dtype=np.uint8)
    controls.append((register(constant, constant[::4, ::4], Degradation()), None))
    return calibrate(controls)


def vosr_calibration_thresholds(probes):
    """Calibrate SR acceptance using zero-injection and shifted VOSR controls."""
    controls = []
    examples = [probe_images(probes[key]) for key in CALIBRATION_IDS]
    for index, (_, lr, prediction, degradation) in enumerate(examples):
        ux, uy = DIRECTIONS[index]
        shifts = [(0, 0)] + [(sign * n * ux, sign * n * uy) for n in MAGNITUDES for sign in (-1, 1)]
        for dx, dy in shifts:
            moving = translated(prediction, dx, dy)
            controls.append((register(moving, lr, degradation), (-dx, -dy)))
        unrelated_lr = examples[(index + 1) % len(examples)][1]
        controls.append((register(prediction, unrelated_lr, degradation), None))
    constant = np.full((512, 512), 128, dtype=np.uint8)
    controls.append((register(constant, constant[::4, ::4], Degradation()), None))
    return calibrate(controls)


def collect_cases(probes, thresholds, sr_thresholds=None):
    rows, score_pairs = [], []
    for index, key in enumerate(TEST_IDS):
        probe = probes[key]
        gt, observed_lr, sr, degradation = probe_images(probe)
        noiseless_lr = degrade_to_lr(gt, observed_lr.shape[::-1], degradation)
        ux, uy = DIRECTIONS[index % len(DIRECTIONS)]
        cohorts = [("vosr", sr, observed_lr)]
        if sr_thresholds is None:
            cohorts.insert(0, ("controlled", gt, noiseless_lr))
        for cohort, prediction, lr in cohorts:
            clean_hr = register(gt, lr, degradation)
            clean_sr = clean_hr if cohort == "controlled" else register(prediction, lr, degradation)
            variants = [("clean", 0, gt, prediction, lr, (0, 0), (0, 0))]
            for magnitude in MAGNITUDES:
                dx, dy = magnitude * ux, magnitude * uy
                left_hr = translated(gt, -dx, -dy)
                right_sr = translated(prediction, dx, dy)
                variants.extend([
                    ("hr_shift", magnitude, left_hr, prediction, lr, (-dx, -dy), (0, 0)),
                    ("sr_shift", magnitude, gt, right_sr, lr, (0, 0), (dx, dy)),
                ])
                if cohort == "controlled" and magnitude == max(MAGNITUDES):
                    new_lr = degrade_to_lr(left_hr, observed_lr.shape[::-1], degradation)
                    variants.append(("anchor_swapped", magnitude, left_hr, prediction, new_lr, (0, 0), (dx, dy)))
            displacement = (INJECTED_RADIUS * ux, INJECTED_RADIUS * uy)
            roi = probe["roi_hr_xyxy_exclusive"]
            variants.extend([
                ("local_sr_shift", INJECTED_RADIUS, gt, local_change(prediction, roi, displacement), lr, (0, 0), (0, 0)),
                ("local_sr_blur", 0, gt, local_change(prediction, roi), lr, (0, 0), (0, 0)),
            ])
            for condition, magnitude, reference, restored, anchor, hr_injection, sr_injection in variants:
                hr_fit = clean_hr if reference is gt and anchor is lr else register(reference, anchor, degradation)
                sr_fit = clean_sr if restored is prediction and anchor is lr else register(restored, anchor, degradation)
                attribution = classify(hr_fit, sr_fit, thresholds, sr_thresholds=sr_thresholds)
                direct_shift = direct_correction(reference, restored)
                lr_shift = hr_fit.shift if attribution.label == "reference_shift" else (0, 0)
                oracle_shift = tuple(-coordinate for coordinate in hr_injection)
                compare_to = [reference, translated(reference, *direct_shift), translated(reference, *lr_shift),
                              translated(reference, *oracle_shift)]
                interior = np.s_[SCORE_MARGIN:-SCORE_MARGIN, SCORE_MARGIN:-SCORE_MARGIN]
                score_pairs.extend((restored[interior], candidate[interior]) for candidate in compare_to)
                rows.append({
                    "pair_id": key,
                    "target": probe["target"],
                    "cohort": cohort,
                    "condition": condition,
                    "magnitude_hr_px": magnitude,
                    "expected_global_label": LABELS[condition],
                    "lr_label": attribution.label,
                    "hr_fit_status": attribution.hr_status,
                    "sr_fit_status": attribution.sr_status,
                    "hr_injected_dxdy": hr_injection,
                    "sr_injected_dxdy": sr_injection,
                    "direct_corrective_dxdy": direct_shift,
                    "lr_hr_corrective_dxdy": hr_fit.shift,
                    "lr_sr_corrective_dxdy": sr_fit.shift,
                    "lr_applied_hr_corrective_dxdy": lr_shift,
                    "oracle_corrective_dxdy": oracle_shift,
                    "lr_hr_rmse": hr_fit.rmse,
                    "lr_sr_rmse": sr_fit.rmse,
                    "lr_hr_margin": hr_fit.margin,
                    "lr_sr_margin": sr_fit.margin,
                })
    return rows, score_pairs


def summarize(rows):
    groups = {}
    for row in rows:
        key = f"{row['cohort']}/{row['condition']}/{row['magnitude_hr_px']}"
        groups.setdefault(key, []).append(row)
    summary = {}
    for key, group in groups.items():
        summary[key] = {
            "n": len(group),
            "correct_global_label": sum(row["lr_label"] == row["expected_global_label"] for row in group),
            "ambiguous": sum(row["lr_label"] == "ambiguous" for row in group),
            "assigned_wrong_global_label": sum(
                row["lr_label"] not in ("ambiguous", row["expected_global_label"]) for row in group
            ),
            "hr_corrected": sum(row["lr_applied_hr_corrective_dxdy"] != (0, 0) for row in group),
            "hr_exactly_corrected": sum(
                row["oracle_corrective_dxdy"] != (0, 0)
                and row["lr_applied_hr_corrective_dxdy"] == row["oracle_corrective_dxdy"] for row in group
            ),
            "median_paper_shafe": {
                method: median(row[f"{method}_paper_shafe"] for row in group)
                for method in ("raw", "direct", "lr", "oracle")
            },
        }
    return summary


def run(weight, threads, out, use_vosr_calibration=False):
    cv2.setNumThreads(1)
    manifest = json.loads((PROBES / "manifest.json").read_text(encoding="utf-8"))
    probes = {probe["pair_id"]: probe for probe in manifest["pairs"]}
    thresholds = calibration_thresholds(probes)
    print(f"Calibration: {thresholds}", flush=True)
    sr_thresholds = vosr_calibration_thresholds(probes) if use_vosr_calibration else None
    if sr_thresholds is not None:
        print(f"VOSR calibration: {sr_thresholds}", flush=True)
    rows, score_pairs = collect_cases(probes, thresholds, sr_thresholds)
    print(f"Scoring {len(rows)} conditions and {len(score_pairs)} image pairs", flush=True)
    metric = load_metric(weight, threads)
    scores = score(metric, score_pairs)
    for index, row in enumerate(rows):
        for method, values in zip(("raw", "direct", "lr", "oracle"), scores[4 * index:4 * index + 4]):
            row.update({f"{method}_{name}": value for name, value in values.items()})
    by_case = {(row["pair_id"], row["cohort"], row["condition"], row["magnitude_hr_px"]): row for row in rows}
    if not use_vosr_calibration:
        for key in TEST_IDS:
            hr = by_case[(key, "controlled", "hr_shift", max(MAGNITUDES))]
            swapped = by_case[(key, "controlled", "anchor_swapped", max(MAGNITUDES))]
            assert abs(hr["raw_paper_shafe"] - swapped["raw_paper_shafe"]) < 1e-6

    summary = {
        "provenance": provenance(metric),
        "held_out_test_ids": TEST_IDS,
        "calibration_probe_ids": CALIBRATION_IDS,
        "thresholds": asdict(thresholds),
        "search_radius_hr_px": SEARCH_RADIUS,
        "score_crop_margin_hr_px": SCORE_MARGIN,
        "global_shift_hr_px": MAGNITUDES,
        "controlled_lr": "Pillow blur and bicubic downsample of anchor GT in grayscale; no noise",
        "vosr_lr": "existing noisy LR PNG used to generate the VOSR output",
        "local_changes": "only SR ROI changed, 12px cosine feather; blur radius 3 or shift 6px",
        "label_scope": "labels describe global translation; aligned on a local change does not attest structural correctness",
        "results": summarize(rows),
    }
    name = "shafe_attribution"
    if sr_thresholds is not None:
        name = "shafe_attribution_vosr_calibrated"
        summary["vosr_sr_thresholds"] = asdict(sr_thresholds)
        summary["vosr_sr_calibration"] = (
            "Unshifted VOSR output assumed globally registered for calibration. "
            "Each scene contributes five known injected shifts, one cross-scene negative, "
            "and the calibration set includes one uniform negative."
        )
    write_results(out, name, rows, summary)
    print(json.dumps(summary["results"], indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--weight", type=Path, default=DEFAULT_WEIGHT)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--out", type=Path, default=HERE / "results")
    parser.add_argument("--vosr-calibration", action="store_true", help="Calibrate SR thresholds on VOSR outputs")
    args = parser.parse_args()
    run(args.weight.resolve(), args.threads, args.out, args.vosr_calibration)


if __name__ == "__main__":
    main()
