"""Register candidate images independently to a fixed low-resolution observation."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from math import ceil
from typing import Iterable

import numpy as np
from PIL import Image, ImageFilter


Shift = tuple[int, int]
_MIN_MARGIN = 1e-6


@dataclass(frozen=True)
class Degradation:
    """Noiseless mean of the paired-probe forward model in LR anchor coordinates."""

    blur_sigma_hr: float = 0.0
    haze_retained: float = 1.0
    haze_box: tuple[int, int, int, int] | None = None

    def __post_init__(self) -> None:
        if not np.isfinite(self.blur_sigma_hr) or self.blur_sigma_hr < 0:
            raise ValueError("blur_sigma_hr must be finite and nonnegative")
        if not 0 <= self.haze_retained <= 1:
            raise ValueError("haze_retained must be between zero and one")
        if self.haze_retained < 1 and self.haze_box is None:
            raise ValueError("haze_box is required for a nonidentity haze operator")


@dataclass(frozen=True)
class Registration:
    """Corrective HR-pixel shifts in (right, down) order, with RGB RMSE in [0, 255]."""

    shift: Shift
    runner_up_shift: Shift
    rmse: float
    runner_up_rmse: float
    margin: float
    at_search_boundary: bool
    valid_lr_box: tuple[int, int, int, int]


@dataclass(frozen=True)
class Thresholds:
    max_rmse: float | None
    min_margin: float | None
    calibration_n: int
    expected_identifiable_n: int
    accepted_correct_n: int
    accepted_incorrect_or_unknown_n: int


@dataclass(frozen=True)
class Attribution:
    label: str
    hr_status: str
    sr_status: str
    hr: Registration
    sr: Registration


def _as_rgb(image: np.ndarray | Image.Image) -> np.ndarray:
    if isinstance(image, Image.Image):
        return np.asarray(image.convert("RGB"))
    pixels = np.asarray(image)
    if pixels.dtype != np.uint8 or pixels.ndim not in (2, 3) or not pixels.size:
        raise ValueError("expected a nonempty uint8 grayscale or RGB image")
    if pixels.ndim == 2:
        return np.repeat(pixels[:, :, None], 3, axis=2)
    if pixels.shape[2] != 3:
        raise ValueError("expected three RGB channels")
    return pixels


def shift_hr(image: np.ndarray | Image.Image, dx: int, dy: int, fill: int = 0) -> np.ndarray:
    """Translate without wrapping or interpolating and fill the newly exposed edges."""
    pixels = np.asarray(image)
    height, width = pixels.shape[:2]
    shifted = np.full_like(pixels, fill)
    if abs(dx) >= width or abs(dy) >= height:
        return shifted
    x0, x1 = max(dx, 0), min(width + dx, width)
    y0, y1 = max(dy, 0), min(height + dy, height)
    shifted[y0:y1, x0:x1] = pixels[y0 - dy:y1 - dy, x0 - dx:x1 - dx]
    return shifted


def degrade_to_lr(
    image: np.ndarray | Image.Image,
    lr_size: tuple[int, int],
    degradation: Degradation = Degradation(),
) -> np.ndarray:
    """Apply optional local white haze, PIL Gaussian blur and bicubic downsampling."""
    pixels = _as_rgb(image)
    rendered = Image.fromarray(pixels)
    if degradation.haze_retained < 1:
        box = degradation.haze_box
        if box is None:
            raise ValueError("haze box missing")
        x0, y0, x1, y1 = box
        if not (0 <= x0 < x1 <= rendered.width and 0 <= y0 < y1 <= rendered.height):
            raise ValueError("haze box must be within the HR image")
        patch = np.asarray(rendered.crop(box), dtype=np.float32)
        retained = degradation.haze_retained
        haze = np.rint(retained * patch + (1 - retained) * 255).astype(np.uint8)
        rendered.paste(Image.fromarray(haze), box)
    if degradation.blur_sigma_hr > 0:
        rendered = rendered.filter(ImageFilter.GaussianBlur(degradation.blur_sigma_hr))
    return np.asarray(rendered.resize(lr_size, Image.Resampling.BICUBIC))


def register_to_lr(
    moving: np.ndarray | Image.Image,
    observed_lr: np.ndarray | Image.Image,
    *,
    max_shift: int = 6,
    input_border_hr: int = 0,
    degradation: Degradation = Degradation(),
) -> Registration:
    """Search integer translations on a shared crop, excluding any declared input padding."""
    if not isinstance(max_shift, int) or max_shift < 1:
        raise ValueError("max_shift must be a positive integer")
    if not isinstance(input_border_hr, int) or input_border_hr < 0:
        raise ValueError("input_border_hr must be a nonnegative integer")
    source = _as_rgb(moving)
    target = _as_rgb(observed_lr)
    lr_h, lr_w = target.shape[:2]
    hr_h, hr_w = source.shape[:2]
    if hr_h < lr_h or hr_w < lr_w:
        raise ValueError("candidate image must be at least as large as the LR observation")

    # Exclude padding from both the input and candidate shifts, plus filter support.
    blur = degradation.blur_sigma_hr
    blur_support = 3 * ceil(blur) if blur else 0
    pad_hr = max_shift + input_border_hr + blur_support
    pad_x = ceil(pad_hr * lr_w / hr_w) + (2 if lr_w != hr_w else 0)
    pad_y = ceil(pad_hr * lr_h / hr_h) + (2 if lr_h != hr_h else 0)
    x0, y0, x1, y1 = pad_x, pad_y, lr_w - pad_x, lr_h - pad_y
    if x1 <= x0 or y1 <= y0:
        raise ValueError("LR observation has no common interior for the requested shift and blur")
    common_crop = np.s_[y0:y1, x0:x1]
    target_interior = target[common_crop].astype(np.float32)

    scale_x, remainder_x = divmod(hr_w, lr_w)
    scale_y, remainder_y = divmod(hr_h, lr_h)
    preblurred = None
    if degradation.haze_retained == 1:
        # Away from padding, Gaussian blur and integer translation commute.
        preblurred = Image.fromarray(source)
        if blur:
            preblurred = preblurred.filter(ImageFilter.GaussianBlur(blur))
        source = np.asarray(preblurred)

    scores = []
    for dy in range(-max_shift, max_shift + 1):
        for dx in range(-max_shift, max_shift + 1):
            if preblurred is not None and remainder_x == remainder_y == 0:
                # Integer scales preserve the full resize grid when sampling a crop directly.
                box = (x0 * scale_x - dx, y0 * scale_y - dy, x1 * scale_x - dx, y1 * scale_y - dy)
                resized = preblurred.resize((x1 - x0, y1 - y0), Image.Resampling.BICUBIC, box=box)
                predicted = np.asarray(resized)
            else:
                shifted = source if (dx, dy) == (0, 0) else shift_hr(source, dx, dy)
                if preblurred is None:
                    resized = degrade_to_lr(shifted, (lr_w, lr_h), degradation)
                else:
                    resized = Image.fromarray(shifted).resize((lr_w, lr_h), Image.Resampling.BICUBIC)
                predicted = np.asarray(resized)[common_crop]
            residual = predicted - target_interior
            rmse = float(np.sqrt(np.mean(residual * residual, dtype=np.float64)))
            scores.append((rmse, dx * dx + dy * dy, dx, dy))

    best, runner_up = sorted(scores)[:2]
    best_rmse, _, dx, dy = best
    next_rmse, _, next_dx, next_dy = runner_up
    return Registration(
        shift=(dx, dy),
        runner_up_shift=(next_dx, next_dy),
        rmse=best_rmse,
        runner_up_rmse=next_rmse,
        margin=next_rmse - best_rmse,
        at_search_boundary=max(abs(dx), abs(dy)) == max_shift,
        valid_lr_box=(x0, y0, x1, y1),
    )


def calibrate(controls: Iterable[tuple[Registration, Shift | None]]) -> Thresholds:
    """Fit one conservative acceptance rule from labeled calibration registrations.

    A control shift is corrective. Use None for unidentifiable or unrelated controls.
    Maximize known-correct acceptance subject to zero known-incorrect acceptances.
    A small fixed slack from positive control extrema accommodates measurement variation.
    """
    controls = list(controls)
    if not controls:
        raise ValueError("provide registrations from a separate calibration cohort")
    eligible = [
        (result, expected)
        for result, expected in controls
        if not result.at_search_boundary and result.margin >= _MIN_MARGIN
    ]
    good = [result for result, expected in eligible if result.shift == expected]
    bad = [result for result, expected in eligible if result.shift != expected]
    expected_n = sum(expected is not None for _, expected in controls)
    if not good:
        return Thresholds(None, None, len(controls), expected_n, 0, 0)

    desired_rmse = 1.15 * max(result.rmse for result in good) + 0.1
    desired_margin = max(_MIN_MARGIN, 0.8 * min(result.margin for result in good))
    rmse_options = {desired_rmse, *(result.rmse for result in good)}
    rmse_options.update(
        float(np.nextafter(result.rmse, -np.inf))
        for result in bad
        if result.rmse <= desired_rmse
    )

    best = None
    for max_rmse in sorted(rmse_options):
        blocking_margin = max((result.margin for result in bad if result.rmse <= max_rmse), default=0.0)
        accepted_margins = [
            result.margin for result in good
            if result.rmse <= max_rmse and result.margin >= desired_margin and result.margin > blocking_margin
        ]
        if not accepted_margins:
            continue
        min_margin = desired_margin
        if min_margin <= blocking_margin:
            min_margin = (blocking_margin + min(accepted_margins)) / 2
            min_margin = max(min_margin, float(np.nextafter(blocking_margin, np.inf)))
        slack_loss = (desired_rmse - max_rmse) / desired_rmse + (min_margin - desired_margin) / desired_margin
        candidate = (-len(accepted_margins), slack_loss, max_rmse, min_margin)
        if best is None or candidate < best:
            best = candidate

    if best is None:
        return Thresholds(None, None, len(controls), expected_n, 0, 0)
    negative_count, _, max_rmse, min_margin = best
    return Thresholds(max_rmse, min_margin, len(controls), expected_n, -negative_count, 0)


def _status(result: Registration, thresholds: Thresholds) -> str:
    if thresholds.max_rmse is None or thresholds.min_margin is None:
        return "calibration_unavailable"
    if result.at_search_boundary:
        return "search_boundary"
    if result.rmse > thresholds.max_rmse:
        return "residual_above_calibration"
    if result.margin < thresholds.min_margin:
        return "weak_margin"
    return "accepted"


def classify(
    hr: Registration, sr: Registration, thresholds: Thresholds, *, sr_thresholds: Thresholds | None = None
) -> Attribution:
    """Attribute observable translational discrepancies with a calibrated reject option."""
    hr_status = _status(hr, thresholds)
    sr_status = _status(sr, sr_thresholds if sr_thresholds is not None else thresholds)
    if hr_status != "accepted" or sr_status != "accepted":
        label = "ambiguous"
    elif hr.shift == sr.shift:
        label = "aligned" if hr.shift == (0, 0) else "shared_shift"
    elif hr.shift == (0, 0):
        label = "restoration_shift"
    elif sr.shift == (0, 0):
        label = "reference_shift"
    else:
        label = "both_shift"
    return Attribution(label, hr_status, sr_status, hr, sr)


def attribute(
    hr: np.ndarray | Image.Image,
    sr: np.ndarray | Image.Image,
    lr: np.ndarray | Image.Image,
    *,
    thresholds: Thresholds,
    max_shift: int = 6,
    input_border_hr: int = 0,
    degradation: Degradation = Degradation(),
) -> Attribution:
    """Convenience method to register both images and classify the resulting shifts."""
    if _as_rgb(hr).shape != _as_rgb(sr).shape:
        raise ValueError("HR and SR images must share the same dimensions")
    hr_registration = register_to_lr(
        hr, lr, max_shift=max_shift, input_border_hr=input_border_hr, degradation=degradation,
    )
    sr_registration = register_to_lr(
        sr, lr, max_shift=max_shift, input_border_hr=input_border_hr, degradation=degradation,
    )
    return classify(hr_registration, sr_registration, thresholds)


def _self_test() -> None:
    rng = np.random.default_rng(20261119)
    spec = Degradation(blur_sigma_hr=0.95, haze_retained=0.45, haze_box=(24, 22, 85, 80))
    lr_size = (32, 28)

    def fixture() -> tuple[np.ndarray, np.ndarray]:
        patches = rng.integers(20, 236, size=(14, 16, 3), dtype=np.uint8)
        clean = np.asarray(Image.fromarray(patches).resize((128, 112), Image.Resampling.BICUBIC))
        return clean, degrade_to_lr(clean, lr_size, spec)

    def register(image: np.ndarray, lr: np.ndarray) -> Registration:
        return register_to_lr(image, lr, max_shift=4, input_border_hr=4, degradation=spec)

    reference, lr = fixture()
    controls = [(register(reference, lr), (0, 0)), (register(shift_hr(reference, -2, 1), lr), (2, -1))]
    unrelated, _ = fixture()
    controls.append((register(unrelated, lr), None))
    thresholds = calibrate(controls)
    assert thresholds.accepted_correct_n == 2
    assert all(result.valid_lr_box == controls[0][0].valid_lr_box for result, _ in controls)
    blocked = calibrate([(controls[0][0], (0, 0)), (controls[0][0], None)])
    assert blocked.accepted_correct_n == 0 and blocked.max_rmse is None

    reference, lr = fixture()
    aligned = register(reference, lr)
    shifted = register(shift_hr(reference, 2, -1), lr)
    other = register(shift_hr(reference, -1, -2), lr)
    boundary = register(shift_hr(reference, 4, 0), lr)
    assert shifted.shift == (-2, 1) and shifted.rmse == 0
    assert classify(aligned, aligned, thresholds).label == "aligned"
    assert classify(shifted, aligned, thresholds).label == "reference_shift"
    assert classify(aligned, shifted, thresholds).label == "restoration_shift"
    assert classify(shifted, shifted, thresholds).label == "shared_shift"
    assert classify(shifted, other, thresholds).label == "both_shift"
    assert classify(aligned, boundary, thresholds).sr_status == "search_boundary"

    flat = np.full_like(reference, 128)
    flat_lr = degrade_to_lr(flat, lr_size, spec)
    rejected = attribute(
        flat, flat, flat_lr, thresholds=thresholds, max_shift=4, input_border_hr=4, degradation=spec,
    )
    assert rejected.label == "ambiguous" and rejected.hr_status == "weak_margin"
    assert np.all(shift_hr(reference, 1, 0)[:, 0] == 0)
    print("lr_anchor self-test passed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        _self_test()
    else:
        parser.print_help()
