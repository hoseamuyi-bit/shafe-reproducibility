# VOSR 0.5B 第 6–7 天实验复现

在 Windows PowerShell 中进入含有 `work/` 的解压目录。压缩包包含冻结的合成输入、真值、掩码、两批原始模型输出、所有评分表、校准系数和运行记录。ScreenSR、TextZoom 与模型文件从发布源补取。需要保留既有结果时，在另一份解压目录重跑。

## 离线核对

Python 3.11 和 NumPy 够用来从已归档评分表重算主区间。逐图重评分另需 Pillow、SciPy、scikit-image 和下列环境中的其他数值包。两个种子是同一场景的重复测量。置信区间以场景为单位，抽样 20,000 次。

```powershell
$Py = './.venv/Scripts/python.exe'
$Day = './work/day67'
& $Py "$Day/robustness/confirmatory_analysis.py" --require-optional --out "$Day/robustness/confirmatory_recheck.json"
& $Py "$Day/robustness/margin_sensitivity.py" --out "$Day/robustness/margin_recheck.json"
& "$Day/robustness/score_confirmation.ps1" -Python $Py
& $Py work/paired_probes/evaluate_outputs.py --probe-dir "$Day/confirm_set" --bicubic --out "$Day/confirm_evaluation/bicubic"
& $Py "$Day/render_results.py" --overview './outputs/资源与内容复核.png' --cases './outputs/固定案例复核.png'
```

`SHA256SUMS` 列出归档内每个文件的 SHA-256。原始资源对照在 `bench/`，同一会话复测在 `bench_repeat/`。正式合成判据见 `robustness/confirmatory_protocol.md`。TextZoom 每词 OCR 结果和配对统计在 `real_text/ocr_*/`，资源每图耗时在各组 `run.json`。

## 环境与 GPU 推理

实测为 Windows x64、Python 3.11.9、单卡 RTX 2060 6 GiB、PyTorch 2.11.0+cu126 和 torchvision 0.26.0+cu126。已有环境可直接将 `$Py` 指向相应的 `python.exe`。首次下载模型约 2.7 GB。模型引导需要 `curl.exe`，整卡显存采样需要 `nvidia-smi`。

```powershell
py -3.11 -m venv .venv
$Py = './.venv/Scripts/python.exe'
$Day = './work/day67'
$Base = './work/baseline_data'
& $Py -m pip install torch==2.11.0 torchvision==0.26.0 --index-url https://download.pytorch.org/whl/cu126
& $Py -m pip install diffusers==0.43.0 transformers==5.23.0 accelerate==1.16.0 huggingface-hub==2.4.0 safetensors==0.8.0 numpy==2.4.6 scipy==1.17.1 Pillow==13.0.0 psutil==7.2.2 timm==1.0.24 fairscale==0.4.13 scikit-image==0.25.2 imageio==2.37.2 einops==0.8.1 tqdm==4.70.1 opencv-python==5.1.0.95 matplotlib==3.11.2
& $Py ./work/reproduction/bootstrap_assets.py --root ./work
& $Py ./work/vosr/run_baseline.py --verify-weights
```

引导脚本固定 VOSR 和 DINOv2 源码提交，并用 `work/vosr/verified_weights.json` 验证权重。合成推理包装器检查已有组的输入数、随机种子、倍率和输出数，完整归档直接复用。如需压测实际重跑，在独立解压目录把 `calibration_runs`、`confirm_runs` 和 `bench_repeat` 移到留存目录，再使用以下命令。12 对 ScreenSR 采用原生 512×512、×1，合成与文字输入 128×128、×4。各组批量为 1，走同一单步模型。

```powershell
& "$Day/run_cohorts.ps1" -Python $Py
& "$Day/robustness/score_confirmation.ps1" -Python $Py
& $Py "$Base/prepare_screensr.py" --listings "$Base/listings"
& "$Day/run_cohorts.ps1" -Python $Py -ResourceBench
$Bench = "$Day/bench_repeat"
& $Py "$Day/compare_benchmarks.py" --fp32 "$Bench/fp32" --fp16 "$Bench/fp16" --packed-w8 "$Bench/packed_w8" --packed-w4 "$Bench/packed_w4" --out "$Bench/compare"
```

模型和数据源见 [VOSR 固定提交](https://github.com/cswry/VOSR/tree/516f292b99cf23c76fdc33351e86dc4f97711fe8)、[DINOv2 固定提交](https://github.com/facebookresearch/dinov2/tree/7764ea0f912e53c92e82eb78a2a1631e92725fc8) 和 [ScreenSR 官方数据](https://modelscope.cn/datasets/LULALULALU/ScreenSR)。

## 匹配预算的输出校准

从已归档的 30 对 FP32／W4 原始输出重拟合。三个配置各用同一个四参数滤波器。训练期的 ROI 仅用于计算损失。应用期逐图读取 W4 输出。若要重审拟合时的完整跨集合像素散列核对，从第 4–5 天扩样复现包补齐 `work/day45/probes/dataset` 和 `seed2027_subset` 内的图像，向 `fit` 命令各追加一个 `--holdout`。只重拟合时，省去这些参数会少两份清单来源记录，拟合公式与数据相同。

```powershell
$Adapter = "$Day/design/matched_adapter.py"
& $Py $Adapter fit --data "$Day/calibration_set" --teacher "$Day/calibration_runs/fp32/images" --student "$Day/calibration_runs/packed_w4/images" --holdout "$Day/confirm_set" --out "$Day/design/fit_recheck.json"
foreach ($Seed in @(42, 2027)) {
    $Runs = "$Day/confirm_runs/seed$Seed"
    $Adapted = "$Day/design/confirm${Seed}_adapted"
    & $Py $Adapter apply --fit "$Day/design/fit.json" --input "$Runs/packed_w4/images" --out $Adapted
    & $Py ./work/paired_probes/evaluate_outputs.py --probe-dir "$Day/confirm_set" --reference fp32 --inference-seed $Seed --variant "fp32=$Runs/fp32/images" --variant "packed_w4=$Runs/packed_w4/images" --variant "pixel=$Adapted/pixel" --variant "pixel_feature=$Adapted/pixel_feature" --variant "pixel_feature_pair=$Adapted/pixel_feature_pair" --out "$Day/design/confirm${Seed}_eval"
}
& $Py "$Day/design/summarize_adapter.py" --cohort "$Day/confirm_set" --evaluation "$Day/design/confirm42_eval" --evaluation "$Day/design/confirm2027_eval" --out "$Day/design/confirm_repeated_recheck.json"
```

第 4–5 天队列的校准复核可用扩样复现包的基础输入、FP32 和 W4 结果。读取本包中的 `design/holdout42_eval` 与 `design/holdout2027_eval` 可直接复算评分汇总。

## 真实文字配对

样本取自 TextZoom 的冻结测试集镜像，抽取易／中／难 17／17／16 个独立场景。 `prepare_textzoom.py` 验证原始 Parquet 的大小与 SHA-256。OpenCV Zoo CRNN 和 PP-OCRv4 分别判分，模型权重均按 SHA-256 校验。原始发布标签用于主评分。两套识别器分别保留逐词原文、归一化结果和编辑距离。 [TextZoom 论文](https://www.ecva.net/papers/eccv_2020/papers_ECCV/html/1186_ECCV_2020_paper.php) · [固定数据镜像](https://huggingface.co/datasets/AKCITPixel3/deblur-ocr-eval/tree/a460d7e2d03d29b174c714598d30445955f8f44e) · [OpenCV Zoo CRNN](https://github.com/opencv/opencv_zoo/tree/main/models/text_recognition_crnn) · [RapidOCR 模型清单](https://rapidai.github.io/RapidOCRDocs/v1.4.4/model_list/)

```powershell
& $Py -m pip install pyarrow==26.0.1 rapidocr-onnxruntime==1.4.4 onnxruntime==1.24.4
$Real = "$Day/real_text"
$Source = "$Real/source"
New-Item -ItemType Directory -Force $Source | Out-Null
$Url = 'https://huggingface.co/datasets/AKCITPixel3/deblur-ocr-eval/resolve/a460d7e2d03d29b174c714598d30445955f8f44e/data/test-00000-of-00001.parquet'
curl.exe --fail --location --retry 3 $Url --output "$Source/textzoom.parquet"
& $Py "$Real/prepare_textzoom.py" --source "$Source/textzoom.parquet" --output $Real
& "$Day/run_cohorts.ps1" -Python $Py -RealText
& $Py "$Day/fetch_ocr_checkpoint.py" --output "$Source/crnn_en.onnx"
$PpOcr = & $Py -c "from pathlib import Path; import rapidocr_onnxruntime as r; print(Path(r.__file__).parent / 'models' / 'ch_PP-OCRv4_rec_infer.onnx')"
$Variants = @()
foreach ($RunName in @('fp32', 'packed_w4', 'packed_w8', 'fp16')) {
    $Variants += @('--variant', "$RunName=$Day/real_text_runs/$RunName/images")
}
& $Py "$Day/score_real_text.py" --manifest "$Real/manifest.json" --recognizer crnn --checkpoint "$Source/crnn_en.onnx" --checkpoint-sha256 a84b1f6e11a65c2d733cb0cc1f014aae3f99051e3f11447dc282faa678eee544 @Variants --out "$Real/ocr_all_crnn"
& $Py "$Day/score_real_text.py" --manifest "$Real/manifest.json" --recognizer ppocr --checkpoint $PpOcr --checkpoint-sha256 48fc40f24f6d2a207a2b1091d3437eb3cc3eb6b676dc3ef9c37384005483683b @Variants --out "$Real/ocr_all_ppocr"
```

复核冻结校准对真实文字的探索性迁移时，使用上一节的 `apply` 命令，以 `$Day/real_text_runs/packed_w4/images` 为输入。往 `$Variants` 中另加 `pixel`、`pixel_feature` 和 `pixel_feature_pair` 三个目录，并使用新的 OCR 输出目录。原始标签仍用于配对计数。
