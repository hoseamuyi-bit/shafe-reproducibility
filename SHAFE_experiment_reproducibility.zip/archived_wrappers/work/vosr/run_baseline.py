import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import threading
import time
from types import SimpleNamespace
from unittest.mock import patch


ROOT = Path(os.environ.get("VOSR_WORK_ROOT", Path(__file__).resolve().parent)).resolve()
CHECKPOINT = ROOT / "ckpts"
WEIGHTS = {
    "VOSR_0.5B_os/args.json": "21b0a82cb72cbd8304a945396980c60bb4f030cb3c8211597a4e8f42f1323212",
    "VOSR_0.5B_os/checkpoints/ema_model.safetensors": "45b6687b4ce59fa3451300f9e0fdcaf2e729c15e65f444af210a7851dfa13203",
    "sd21_lwdecoder.pth": "a326a5e5c4a2445ce970987695979f3d5e5413d39b98c73a2ddac0055d2cdf59",
    "stable-diffusion-2-1-base/vae/config.json": "424117cb534ce03497c41305ed868980123917b2b6abba4bbaa615e968772903",
    "stable-diffusion-2-1-base/vae/diffusion_pytorch_model.safetensors": "a1d993488569e928462932c8c38a0760b874d166399b14414135bd9c42df5815",
    "torch_cache/checkpoints/dinov2_vitb14_pretrain.pth": "0b8b82f85de91b424aded121c7e1dcc2b7bc6d0adeea651bf73a13307fad8c73",
}


def verify_weights():
    files = {}
    for name, expected in WEIGHTS.items():
        path = CHECKPOINT / name
        with path.open("rb") as stream:
            actual = hashlib.file_digest(stream, "sha256").hexdigest()
        if actual != expected:
            raise ValueError(f"SHA-256 mismatch for {name}: {actual}")
        files[name] = {"sha256": actual, "bytes": path.stat().st_size}
    print(json.dumps(files, indent=2))


class Monitor:
    def __init__(self, psutil):
        self.psutil = psutil
        self.process = psutil.Process()
        self.stop = threading.Event()
        self.samples = []
        self.gpu = []
        self.pagefile_error = None
        query = ["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"]
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self.gpu_start = int(subprocess.check_output(query, text=True, creationflags=flags).splitlines()[0])
        self.smi = subprocess.Popen(query + ["-lms", "100"], stdout=subprocess.PIPE, text=True, creationflags=flags)
        self.gpu_thread = threading.Thread(target=self.read_gpu, daemon=True)
        self.ram_thread = threading.Thread(target=self.read_ram, daemon=True)
        self.gpu_thread.start()
        self.ram_thread.start()

    def read_gpu(self):
        for line in self.smi.stdout:
            value = line.strip()
            if value.isdecimal():
                self.gpu.append(int(value))

    def read_ram(self):
        while True:
            ram = self.psutil.virtual_memory()
            pagefile = None
            if self.pagefile_error is None:
                try:
                    pagefile = self.psutil.swap_memory().used
                except (OSError, RuntimeError) as error:
                    self.pagefile_error = str(error)
            self.samples.append((ram.total - ram.available, ram.available, pagefile))
            if self.stop.wait(0.1):
                break

    def finish(self):
        self.stop.set()
        self.smi.terminate()
        self.smi.wait(timeout=5)
        self.gpu_thread.join(timeout=2)
        self.ram_thread.join(timeout=2)
        process_memory = self.process.memory_info()
        used, available, swap = zip(*self.samples)
        mib = 2**20
        swap_mib = [value / mib for value in swap if value is not None]
        return {
            "gpu_card_start_mib": self.gpu_start,
            "gpu_card_sampled_peak_mib": max(self.gpu) if self.gpu else None,
            "gpu_sample_count": len(self.gpu),
            "ram_process_peak_wset_mib": getattr(process_memory, "peak_wset", process_memory.rss) / mib,
            "ram_system_used_at_start_mib": used[0] / mib,
            "ram_system_used_sampled_peak_mib": max(used) / mib,
            "ram_system_available_sampled_min_mib": min(available) / mib,
            "pagefile_used_start_mib": swap_mib[0] if swap_mib else None,
            "pagefile_used_sampled_peak_mib": max(swap_mib) if swap_mib else None,
            "pagefile_used_end_mib": swap_mib[-1] if swap_mib else None,
            "pagefile_sampling_error": self.pagefile_error,
            "ram_sample_count": len(used),
        }


def fake_quantize_linear(torch, model, bits):
    limit = 2 ** (bits - 1) - 1
    count = 0
    with torch.no_grad():
        for module in model.modules():
            if isinstance(module, torch.nn.Linear):
                weight = module.weight
                scale = weight.abs().amax(dim=1, keepdim=True).clamp_min(1e-12) / limit
                quantized = (weight / scale).round().clamp(-limit, limit)
                weight.copy_(quantized * scale)
                count += weight.numel()
    return count


def run(cli):
    import psutil

    os.environ["TORCH_COMPILE_DISABLE"] = "1"
    os.environ["XFORMERS_DISABLED"] = "1"
    os.environ["HF_HUB_OFFLINE"] = "1"
    sys.path[:0] = [str(ROOT / "upstream"), str(ROOT / "deps")]
    monitor = Monitor(psutil)
    started = time.perf_counter()
    try:
        import numpy as np
        from PIL import Image
        import torch
        from torchvision import transforms
        import diffusers
        import inference_vosr_onestep as upstream

        torch.set_num_threads(4)
        torch.set_float32_matmul_precision("highest")
        torch.manual_seed(cli.seed)
        torch.cuda.manual_seed_all(cli.seed)
        np.random.seed(cli.seed)
        device = torch.device("cuda")
        torch.cuda.reset_peak_memory_stats()
        imports_s = time.perf_counter() - started
        model_root = CHECKPOINT / "VOSR_0.5B_os"
        args = SimpleNamespace(**json.loads((model_root / "args.json").read_text(encoding="utf-8")))
        args.auxiliary_time_cond = getattr(args, "auxiliary_time_cond", True)
        args.posterior_mode = True
        args.vae_tile_size = 0
        dtype = torch.float16 if cli.precision == "fp16" else torch.float32

        print("Loading SD2 VAE and LightDecoder", flush=True)
        vae = diffusers.AutoencoderKL.from_pretrained(CHECKPOINT / "stable-diffusion-2-1-base", subfolder="vae")
        vae.eval()
        if cli.encoder_only_vae:
            vae.encoder.to(device)
            vae.quant_conv.to(device)
        else:
            vae.to(device)
        decoder_weights = torch.load(CHECKPOINT / "sd21_lwdecoder.pth", map_location="cpu", weights_only=True)
        decoder = upstream.LightDecoder(**decoder_weights["config"])
        decoder.load_state_dict(decoder_weights["model_state_dict"], strict=True)
        del decoder_weights
        decoder.to(device=device, dtype=dtype).eval()

        print("Loading DINOv2", flush=True)
        dino = torch.hub.load(str(ROOT / "dinov2_source"), "dinov2_vitb14", source="local", pretrained=False)
        dino.load_state_dict(torch.load(CHECKPOINT / "torch_cache/checkpoints/dinov2_vitb14_pretrain.pth",
                                        map_location="cpu", weights_only=True), strict=True)
        dino.to(dtype=dtype)
        with patch.object(torch.hub, "load", return_value=dino):
            dino = upstream.load_dinov2(args, "cpu" if cli.early_dino else device)
        if cli.early_dino:
            if args.layer_dinov2b_list != [8] or len(dino.blocks) != 12:
                raise ValueError("DINO early exit expects only block index 8 of 12")
            dino.blocks = dino.blocks[:9]
            dino.to(device)

        print("Loading LightningDiT", flush=True)
        model = upstream.LightningDiT(
            input_size=args.resolution // 8,
            patch_size=args.patch_size,
            in_channels=8,
            out_channels=4,
            hidden_size=args.dim,
            depth=args.depth,
            num_heads=args.num_heads,
            mlp_ratio=args.mlp_ratio,
            z_dims=args.enc_dim,
            encdim_ratio=args.encdim_ratio,
            auxiliary_time_cond=args.auxiliary_time_cond,
            use_qknorm=args.use_qknorm,
            use_swiglu=args.use_swiglu,
            use_rope=args.use_rope,
            use_rmsnorm=args.use_rmsnorm,
            wo_shift=args.wo_shift,
            num_fused_layers=len(args.layer_dinov2b_list),
        )
        weights = upstream.load_file(model_root / "checkpoints/ema_model.safetensors", device="cpu")
        model.load_state_dict(weights, strict=True)
        del weights
        quantized_parameters = 0
        packed_w4_storage = None
        packed_w8_storage = None
        if cli.fake_quant_bits:
            quantized_parameters = fake_quantize_linear(torch, model, cli.fake_quant_bits)
        if cli.packed_w4 or cli.packed_w8:
            from packed_w4 import pack_linear_weights

            if cli.packed_w4:
                packed_w4_storage = pack_linear_weights(model, bits=4)
            else:
                packed_w8_storage = pack_linear_weights(model, bits=8)
        model.to(device=device, dtype=dtype).eval()
        model.forward = model.forward_flexible
        sampler = upstream.VOSR(
            time_dist=args.time_dist, cfg_ratio=args.cfg_ratio, cfg_scale=args.cfg_scale,
            interp_type=args.interp_type, accelerator=upstream._inference_accelerator_stub(),
            t_start=args.t_start, t_end=args.t_end, args=args,
        )
        torch.cuda.synchronize()
        load_done = time.perf_counter()
        mib = 2**20
        load_allocated_mib = torch.cuda.max_memory_allocated() / mib
        load_reserved_mib = torch.cuda.max_memory_reserved() / mib
        paths = [Path(path) for path in upstream.list_lq_images(str(cli.input))]
        if cli.prefix:
            paths = [path for path in paths if path.stem.startswith(cli.prefix)]
        if cli.limit:
            paths = paths[:cli.limit]
        if not paths:
            raise ValueError(f"No inputs found in {cli.input}")
        image_dir = cli.output / "images"
        image_dir.mkdir(parents=True, exist_ok=True)
        to_pil, to_tensor = transforms.ToPILImage(), transforms.ToTensor()
        records = []
        for index, path in enumerate(paths):
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            tick = time.perf_counter()
            with Image.open(path) as raw:
                size = raw.size
                reference = raw.convert("RGB").resize(tuple(edge * cli.scale for edge in size), Image.Resampling.BICUBIC)
            if reference.size != (512, 512):
                raise ValueError(f"Expected 512x512 target for {path}, got {reference.size}")
            image = to_tensor(reference).unsqueeze(0).to(device) * 2.0 - 1.0
            torch.cuda.manual_seed(cli.seed)
            with torch.inference_mode():
                latent, mean, std = upstream.encode_dispatch(vae, image, args, device)
                with torch.autocast("cuda", dtype=torch.float16, enabled=cli.precision == "fp16"):
                    if cli.early_dino:
                        normalized = upstream.preprocess_raw_image((0.5 * image + 0.5) * 255, args)
                        tokens = dino.prepare_tokens_with_masks(normalized)
                        for block in dino.blocks:
                            tokens = block(tokens)
                        features = [tokens[:, 1:]]
                    else:
                        features = upstream.get_venc_features(dino, image, args)
                    sampled = sampler.sample_onestep(model, latent, venc_fea=features, n_steps=1)
                    decoded = upstream.decode_dispatch(vae, sampled, args, mean, std, decoder)
                if not torch.isfinite(decoded).all().item():
                    raise ValueError(f"Non-finite model output for {path}")
            restored = to_pil(decoded[0].float().cpu() * 0.5 + 0.5)
            restored = upstream.wavelet_color_fix(restored, reference)
            output = image_dir / f"{path.stem}.png"
            temp = output.with_suffix(".tmp")
            restored.save(temp, format="PNG")
            temp.replace(output)
            torch.cuda.synchronize()
            elapsed = time.perf_counter() - tick
            records.append({
                "filename": output.name, "input_size": size, "output_size": restored.size,
                "latency_s": elapsed, "torch_peak_allocated_mib": torch.cuda.max_memory_allocated() / mib,
                "torch_peak_reserved_mib": torch.cuda.max_memory_reserved() / mib,
            })
            print(f"{index + 1:02d}/{len(paths):02d} {output.name}: {elapsed:.3f} s", flush=True)
        times = [row["latency_s"] for row in records[1:]]
        peak_fields = ("torch_peak_allocated_mib", "torch_peak_reserved_mib")
        summary = {
            "precision": cli.precision, "vae_precision": "fp32", "upscale": cli.scale, "batch": 1,
            "steps": 1, "seed_per_image": cli.seed, "same_cuda_noise_within_precision": True,
            "tile": False, "color_fix": "wavelet", "vae_posterior": "mode", "device": torch.cuda.get_device_name(),
            "torch_version": torch.__version__, "diffusers_version": diffusers.__version__,
            "py_version": sys.version.split()[0], "cuda_runtime": torch.version.cuda,
            "encoder_only_vae": cli.encoder_only_vae, "early_dino": cli.early_dino,
            "fake_quant_bits": cli.fake_quant_bits, "fake_quantized_dit_linear_parameters": quantized_parameters,
            "packed_w4_storage": packed_w4_storage,
            "packed_w8_storage": packed_w8_storage,
            "input_count": len(records), "imports_s": imports_s, "model_init_s": load_done - started - imports_s,
            "input_prefix": cli.prefix,
            "cold_first_output_s": load_done - started + records[0]["latency_s"],
            "first_inference_s": records[0]["latency_s"], "warm_count": len(times),
            "warm_median_s": statistics.median(times) if times else None,
            "warm_p95_linear_s": float(np.quantile(times, 0.95)) if times else None,
            "warm_max_s": max(times) if times else None,
            "torch_peak_allocated_mib": max(load_allocated_mib, *(r[peak_fields[0]] for r in records)),
            "torch_peak_reserved_mib": max(load_reserved_mib, *(r[peak_fields[1]] for r in records)),
            "samples": records,
        }
    finally:
        resource_stats = monitor.finish()
    summary.update(resource_stats)
    (cli.output / "run.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in summary.items() if key != "samples"}, indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--scale", type=int, choices=(1, 4), default=1)
    parser.add_argument("--precision", choices=("fp32", "fp16"), default="fp32")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--prefix")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--encoder-only-vae", action="store_true")
    parser.add_argument("--early-dino", action="store_true")
    quantization = parser.add_mutually_exclusive_group()
    quantization.add_argument("--fake-quant-bits", type=int, choices=(4, 8))
    quantization.add_argument("--packed-w4", action="store_true")
    quantization.add_argument("--packed-w8", action="store_true")
    parser.add_argument("--verify-weights", action="store_true")
    cli = parser.parse_args()
    if (cli.packed_w4 or cli.packed_w8) and cli.precision != "fp32":
        parser.error("--packed-w4 and --packed-w8 require --precision fp32")
    if cli.verify_weights:
        verify_weights()
    else:
        if cli.input is None or cli.output is None:
            parser.error("--input and --output are required")
        run(cli)
