"""Apply the frozen RealSR landmark criteria to the archived robust methods."""

import argparse
from collections import Counter
from datetime import datetime, timezone
from itertools import product
from pathlib import Path

from landmark_analysis import (HERE, LOCK, SOURCES, absolute_offset, dump, evaluate_action,
                               landmark_estimate, load, read_review, sha)


ROOT = HERE.parent.parent
PLAN = HERE / 'robust_review_lock.json'
ACTIONS = ROOT / 'experiment_audit/coco_confirm/sensitivity/realsr_lk_analysis.json'
METHODS = ('raw', 'simple_lr', 'tile_mean', 'tile_trimmed', 'median_lk')
CONDITIONS = ('zero', 'shift2', 'replacement_256', 'shift2_replacement_256')


def hashes():
    paths = (Path(__file__).resolve(), LOCK, ACTIONS, *SOURCES.values())
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in paths}


def freeze():
    if PLAN.exists():
        raise FileExistsError(PLAN)
    dump(PLAN, dict(
        utc=datetime.now(timezone.utc).isoformat(), hashes=hashes(),
        methods=METHODS, conditions=CONDITIONS,
        endpoint='Use the original landmark reliability and action rules unchanged. The zero-injection '
                 'condition measures natural residuals. The other three conditions measure the same HR '
                 'crop with known artificial perturbations. Report each separately, with individual '
                 'cases and camera-specific counts. Preserve undecidable cases and the LK no-track status.',
        inference='Descriptive extension on the original 32 camera scenes. No threshold refitting or '
                  'inference about natural offsets when the blind landmark measurements are unavailable.'))


def score(review_paths, output):
    plan, lock = load(PLAN), load(LOCK)
    if plan['hashes'] != hashes():
        raise ValueError('Frozen review or archived registration changed')
    first, second = (read_review(p, lock) for p in review_paths)
    if first[0].casefold() == second[0].casefold() or first[1] == second[1]:
        raise ValueError('Two independently completed reviews are required')
    baseline = {}
    for alias, info in lock['mapping'].items():
        truth = landmark_estimate([first[1][alias], second[1][alias]], 'hr')
        baseline[info['scene']] = dict(alias=alias, camera=info['camera'], hr=truth)
    cases = []
    source = load(ACTIONS)['rows']
    assert len(source) == 128 and {(r['scene'], r['condition']) for r in source} == set(product(baseline, CONDITIONS))
    for row in source:
        info = baseline[row['scene']]
        assert row['dataset'] == info['camera']
        truth = absolute_offset(info['hr'], row['hr_added'])
        methods = {m: dict(evaluate_action(truth, row['actions'][m]), action=row['actions'][m]) for m in METHODS}
        cases.append(dict(scene=row['scene'], alias=info['alias'], camera=info['camera'],
                          condition=row['condition'], hr=truth, lk_tracks=row['tracks'], methods=methods))
    summaries = []
    for camera, condition in product(('all', 'Canon', 'Nikon'), CONDITIONS):
        subset = [r for r in cases if r['condition'] == condition and camera in ('all', r['camera'])]
        summaries.append(dict(camera=camera, condition=condition, n=len(subset),
                              truth_counts=dict(Counter(r['hr']['status'] for r in subset)),
                              lk_unavailable=sum(r['lk_tracks'] < 8 for r in subset),
                              counts={m: dict(Counter(r['methods'][m]['label'] for r in subset)) for m in METHODS}))
    dump(output, dict(lock_sha256=sha(PLAN), review_digests=[sha(p) for p in review_paths],
                      baseline=baseline, summaries=summaries, cases=cases))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='step', required=True)
    commands.add_parser('freeze')
    evaluation = commands.add_parser('score')
    evaluation.add_argument('reviews', type=Path, nargs=2)
    evaluation.add_argument('output', type=Path)
    args = parser.parse_args()
    if args.step == 'freeze':
        freeze()
    else:
        score(args.reviews, args.output)
