"""Freeze the RealSR review inputs and evaluate two independent review exports."""

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import io
import itertools
import json
from pathlib import Path
import random
import statistics
import zipfile


HERE = Path(__file__).resolve().parent
EXTERNAL = HERE.parent
ROLES = {"lr": 128, "hr": 512, "sr": 512}
CAMERAS = ("Canon", "Nikon")
CONDITIONS = ("zero", "hr_global", "sr_global", "both_global")
METHODS = ("raw", "direct", "simple_lr", "single", "dual", "legacy")
SOURCES = {
    "inputs": EXTERNAL / "landmark_inputs.json",
    "image_manifest": EXTERNAL / "batch_inputs.json",
    "actions": EXTERNAL / "decisions.json",
    "gates": EXTERNAL.parent / "calibration/gates.json",
    "formal_lock": EXTERNAL.parent / "formal_lock.json",
    "plan": HERE / "分析计划.md",
    "analysis": Path(__file__).resolve(),
}
LOCK = HERE / "review_lock.json"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8")


def stage(directory):
    from PIL import Image

    if directory.exists():
        raise ValueError(f"Use an empty staging path: {directory}")
    inputs = load(SOURCES["inputs"])["scenes"]
    records = {row["scene"]: row for row in load(SOURCES["image_manifest"])["records"]}
    if (len(inputs) != 32 or len(records) != 32 or {row["scene"] for row in inputs} != set(records)
            or Counter(row["camera"] for row in inputs) != {"Canon": 16, "Nikon": 16}):
        raise ValueError("Incomplete or unbalanced RealSR review set")

    ordered = sorted(inputs, key=lambda row: row["scene"])
    random.Random("SHAFE | RealSR V3 x4 | independent landmark review | v1").shuffle(ordered)
    files = {name: (HERE / name).read_bytes() for name in ("review.html", "review.js", "评审说明.md")}
    mapping = {}
    for index, row in enumerate(ordered, start=1):
        scene = row["scene"]
        alias = f"S{index:02d}"
        source = records[scene]
        if source["dataset"] != row["camera"]:
            raise ValueError(f"Camera mismatch for {scene}")
        mapping[alias] = {"scene": scene, "camera": row["camera"], "source_sha256": {}}
        for role, size in ROLES.items():
            path = Path(row[role])
            if path != Path(source[role]):
                raise ValueError(f"Image path mismatch for {scene} {role}")
            data = path.read_bytes()
            checksum = digest(data)
            manifest = load(path.with_suffix(".json")) if role == "sr" else source
            if checksum != manifest[f"{role}_sha256"]:
                raise ValueError(f"Image hash mismatch for {scene} {role}")
            mapping[alias]["source_sha256"][role] = checksum
            with Image.open(io.BytesIO(data)) as original:
                if original.size != (size, size) or original.mode != "RGB":
                    raise ValueError(f"Unexpected image grid for {scene} {role}")
                pixels = original.tobytes()
            target = io.BytesIO()
            Image.frombytes("RGB", (size, size), pixels).save(target, format="PNG")
            files[f"images/{alias}/{role}.png"] = target.getvalue()

    bundle_identity = "".join(f"{name}:{digest(files[name])}\n" for name in sorted(files))
    review_set = "realsr-x4-" + digest(bundle_identity.encode("utf-8"))[:16]
    files["scenes.js"] = ("window.REVIEW_SET = " +
                          json.dumps({"id": review_set, "scenes": list(mapping)}) + ";\n").encode()
    for name, data in files.items():
        destination = directory / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    dump(directory.with_suffix(".json"), {
        "review_set": review_set, "mapping": mapping,
        "files": {name: digest(data) for name, data in sorted(files.items())},
        "sources": {name: sha(path) for name, path in SOURCES.items()},
    })


def freeze(directory, archive):
    data = load(directory.with_suffix(".json"))
    matches = {path.relative_to(directory).as_posix(): sha(path)
               for path in directory.rglob("*") if path.is_file()}
    if matches != data["files"] or {name: sha(path) for name, path in SOURCES.items()} != data["sources"]:
        raise ValueError("Review inputs or analysis changed after staging")
    for filename in ("review.html", "review.js", "评审说明.md"):
        if sha(HERE / filename) != matches[filename]:
            raise ValueError(f"Review interface changed after staging: {filename}")
    if LOCK.exists():
        locked = load(LOCK)
        if any(locked[key] != value for key, value in data.items()):
            raise ValueError("A different review protocol is already frozen")
    else:
        data["frozen_utc"] = datetime.now(timezone.utc).isoformat()
        with LOCK.open("x", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
    temporary = archive.with_suffix(".tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name in data["files"]:
            z.writestr(name, (directory / name).read_bytes())
    with zipfile.ZipFile(temporary) as z:
        if {name: digest(z.read(name)) for name in z.namelist()} != data["files"]:
            raise ValueError("Review archive failed verification")
    temporary.replace(archive)


def quadrant(point):
    return int(point[0] >= 63.5) + 2 * int(point[1] >= 63.5)


def read_review(path, lock):
    data = load(path)
    reviewer = data.get("reviewer")
    reviews = data.get("reviews")
    if (data.get("schema") != 1 or data.get("review_set") != lock["review_set"]
            or not isinstance(reviewer, str) or not reviewer.strip() or len(reviewer.strip()) > 40
            or not isinstance(reviews, dict) or set(reviews) != set(lock["mapping"])):
        raise ValueError(f"Wrong review set, reviewer ID, or incomplete scenes in {path.name}")
    for alias, entry in reviews.items():
        points = entry.get("landmarks")
        unavailable = entry.get("unavailable")
        reason = entry.get("reason")
        if not isinstance(points, list) or type(unavailable) is not bool or not isinstance(reason, str):
            raise ValueError(f"Malformed entry {alias} in {path.name}")
        for point in points:
            for role, size in ROLES.items():
                xy = point.get(role)
                if (not isinstance(xy, list) or len(xy) != 2
                        or any(type(v) not in (int, float) or not -0.5 <= v < size - 0.5 for v in xy)):
                    raise ValueError(f"Invalid {role} point in {alias} in {path.name}")
        if unavailable:
            if not reason.strip():
                raise ValueError(f"Missing reason for unavailable scene {alias} in {path.name}")
        else:
            occupied = {quadrant(point["lr"]) for point in points}
            distinct = all(sum((x-y)**2 for x, y in zip(a["lr"], b["lr"])) >= 1
                           for a, b in itertools.combinations(points, 2))
            if len(points) < 8 or len(occupied) != 4 or not distinct:
                raise ValueError(f"Insufficient, clustered, or repeated points for {alias} in {path.name}")
    return reviewer.strip(), reviews


def median_vector(vectors):
    return [statistics.median(axis) for axis in zip(*vectors)]


def diff(first, second):
    return [x - y for x, y in zip(first, second)]


def norm(vector):
    return max(abs(value) for value in vector)


def vectors_by_quadrant(points, role):
    groups = [[] for _ in range(4)]
    for point in points:
        lr = point["lr"]
        xy = [4 * (coordinate + 0.5) - 0.5 for coordinate in lr]
        groups[quadrant(lr)].append(diff(point[role], xy))
    return groups


def describe(groups):
    overall = median_vector(list(itertools.chain.from_iterable(groups)))
    by_quadrant = [median_vector(group) for group in groups]
    return {
        "n_by_quadrant": [len(group) for group in groups],
        "median": overall, "quadrant_medians": by_quadrant,
        "max_quadrant_difference": max(norm(diff(median, overall)) for median in by_quadrant),
    }


def classify(vector):
    size = norm(vector)
    if size <= 1:
        return "no_confirmed_offset"
    if size > 2:
        return "confirmed_offset"
    return "uncertain_magnitude"


def landmark_estimate(entries, role):
    if any(entry["unavailable"] for entry in entries):
        return {
            "status": "insufficient_landmarks", "combined": None,
            "unavailable": [entry["reason"] if entry["unavailable"] else None for entry in entries],
        }
    groups = [vectors_by_quadrant(entry["landmarks"], role) for entry in entries]
    descriptions = [describe(group) for group in groups]
    pooled = describe([first + second for first, second in zip(*groups)])
    medians = [d["median"] for d in descriptions]
    disagreement = norm(diff(*medians))
    combined = [statistics.mean(axis) for axis in zip(*medians)]
    problems = []
    if disagreement > 1:
        problems.append("reviewer_disagreement")
    if any(d["max_quadrant_difference"] > 1 for d in descriptions + [pooled]):
        problems.append("quadrant_inconsistency")
    return {
        "status": "uncertain_reliability" if problems else classify(combined),
        "problems": problems, "combined": combined, "max_reviewer_difference": disagreement,
        "reviewers": descriptions, "pooled": pooled,
    }


def absolute_offset(base, injection):
    if base["status"] not in ("confirmed_offset", "no_confirmed_offset"):
        return {"status": base["status"], "offset": None}
    offset = [x + y for x, y in zip(base["combined"], injection)]
    return {"status": classify(offset), "offset": offset}


def evaluate_action(truth, action):
    if truth["status"] not in ("confirmed_offset", "no_confirmed_offset"):
        return {"label": "not_evaluable", "residual_linf": None}
    residual = norm([x + y for x, y in zip(truth["offset"], action)])
    moved = norm(action) > 0.25
    if truth["status"] == "confirmed_offset":
        label = ("correct" if residual <= 1 else "wrong_vector") if moved else "missed"
    else:
        label = ("moved_over_tolerance" if residual > 1 else "moved_within_tolerance") if moved else "held"
    return {"label": label, "residual_linf": residual}


def summarize(cases):
    groups = defaultdict(list)
    for row in cases:
        for camera in ("all", row["camera"]):
            groups[camera, row["condition"]].append(row)
    result = []
    for (camera, condition), rows in sorted(groups.items()):
        hr_counts = Counter(row["hr"]["status"] for row in rows)
        needs = hr_counts["confirmed_offset"]
        holds = hr_counts["no_confirmed_offset"]
        methods = {}
        for method in METHODS:
            counts = Counter(row["methods"][method]["label"] for row in rows)
            methods[method] = {
                "counts": dict(counts),
                "correct_rate": counts["correct"] / needs if needs else None,
                "action_rate_in_no_confirmed_offset": (
                    (counts["moved_over_tolerance"] + counts["moved_within_tolerance"]) / holds
                    if holds else None),
                "over_tolerance_action_rate_in_no_confirmed_offset": (
                    counts["moved_over_tolerance"] / holds if holds else None),
            }
        result.append({"camera": camera, "condition": condition, "n": len(rows),
                       "hr": dict(hr_counts), "sr": dict(Counter(row["sr"]["status"] for row in rows)),
                       "methods": methods})
    return result


def score(annotation_paths, output):
    lock = load(LOCK)
    if {name: sha(path) for name, path in SOURCES.items()} != lock["sources"]:
        raise ValueError("Frozen decisions, images, or review analysis have changed")
    first, second = (read_review(path, lock) for path in annotation_paths)
    if first[0].casefold() == second[0].casefold():
        raise ValueError("Supply separately completed reviews with distinct reviewer IDs")
    if first[1] == second[1]:
        raise ValueError("The two exports contain identical annotations")
    base = {}
    for alias, mapping in lock["mapping"].items():
        reviews = [first[1][alias], second[1][alias]]
        base[mapping["scene"]] = {"alias": alias, "camera": mapping["camera"],
                                  **{role: landmark_estimate(reviews, role) for role in ("hr", "sr")}}
    cases = []
    decisions = load(SOURCES["actions"])
    expected = set(itertools.product(base, CONDITIONS))
    observed = {(row["scene"], row["condition"]) for row in decisions["rows"]}
    if (expected != observed or len(expected) != len(decisions["rows"])
            or decisions["gates_sha256"] != lock["sources"]["gates"]):
        raise ValueError("Frozen RealSR decisions do not match the review set or gates")
    for row in decisions["rows"]:
        baseline = base[row["scene"]]
        hr, sr = (absolute_offset(baseline[role], row[f"{role}_added"]) for role in ("hr", "sr"))
        methods = {method: {**evaluate_action(hr, row["actions"][method]),
                            "action": row["actions"][method]} for method in METHODS}
        cases.append({"alias": baseline["alias"], "scene": row["scene"], "camera": baseline["camera"],
                      "condition": row["condition"], "hr": hr, "sr": sr, "methods": methods})
    dump(output, {"review_set": lock["review_set"], "lock_sha256": sha(LOCK),
                  "review_sha256": [sha(path) for path in annotation_paths],
                  "independent_reviewers": [first[0], second[0]],
                  "baseline": base, "by_condition": summarize(cases), "cases": cases})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("stage").add_argument("directory", type=Path)
    package = commands.add_parser("freeze")
    package.add_argument("directory", type=Path)
    package.add_argument("archive", type=Path)
    evaluation = commands.add_parser("score")
    evaluation.add_argument("reviews", type=Path, nargs=2)
    evaluation.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.command == "stage":
        stage(args.directory)
    elif args.command == "freeze":
        freeze(args.directory, args.archive)
    else:
        score(args.reviews, args.output)
