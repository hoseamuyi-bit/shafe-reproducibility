"""Exercise the review analysis using artificial coordinates only."""

from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory

from landmark_analysis import (LOCK, absolute_offset, dump, evaluate_action, landmark_estimate,
                               load, read_review, score)
from robust_landmark_analysis import score as score_robust


POINTS = [(20, 18), (33, 38), (76, 20), (103, 32),
          (24, 74), (43, 93), (76, 100), (103, 78)]


def entry(hr, sr, x_bias=0):
    landmarks = []
    for (x, y) in POINTS:
        lr = [x + x_bias, y]
        grid = [4 * p + 1.5 for p in lr]
        landmarks.append({"lr": lr, "hr": [a + b for a, b in zip(grid, hr)],
                          "sr": [a + b for a, b in zip(grid, sr)]})
    return {"landmarks": landmarks, "unavailable": False, "reason": ""}


def main():
    a = entry([3, -1], [1, 0])
    b = entry([3.5, -1], [1, 0], 0.25)
    hr = landmark_estimate([a, b], "hr")
    assert hr["status"] == "confirmed_offset" and hr["combined"] == [3.25, -1]
    assert landmark_estimate([a, b], "sr")["status"] == "no_confirmed_offset"
    b_disagree = entry([4.25, -1], [1, 0])
    assert landmark_estimate([a, b_disagree], "hr")["problems"] == ["reviewer_disagreement"]
    b_quadrant = deepcopy(b)
    for point in b_quadrant["landmarks"][:2]:
        point["hr"][0] -= 2
    assert landmark_estimate([a, b_quadrant], "hr")["problems"] == ["quadrant_inconsistency"]
    assert landmark_estimate([a, {**b, "unavailable": True}], "sr")["status"] == "insufficient_landmarks"
    assert absolute_offset(hr, [-3, 0])["status"] == "no_confirmed_offset"
    assert absolute_offset(hr, [-1.25, 0])["status"] == "uncertain_magnitude"
    assert absolute_offset(hr, [0, 0])["status"] == "confirmed_offset"
    moved = {"status": "confirmed_offset", "offset": [3, -1]}
    held = {"status": "no_confirmed_offset", "offset": [1, 0]}
    for truth, action, label in [
        (moved, [-2, 0], "correct"), (moved, [3, -1], "wrong_vector"), (moved, [0, 0], "missed"),
        (held, [-1, 0], "moved_within_tolerance"), (held, [1, 0], "moved_over_tolerance"),
        (held, [0, 0], "held"), ({"status": "uncertain_magnitude"}, [0, 0], "not_evaluable"),
    ]:
        assert evaluate_action(truth, action)["label"] == label

    lock = load(LOCK)
    with TemporaryDirectory(dir=LOCK.parent) as tmp:
        first, second, output = (Path(tmp) / f"{name}.json" for name in ("fake_1", "fake_2", "test_result"))
        reviews_a = {alias: a for alias in lock["mapping"]}
        reviews_b = {alias: b for alias in lock["mapping"]}
        reviews_b["S05"] = {"landmarks": [], "unavailable": True, "reason": "Synthetic fixture"}
        for index, (path, review) in enumerate(((first, reviews_a), (second, reviews_b)), start=1):
            dump(path, {"schema": 1, "review_set": lock["review_set"],
                        "reviewer": f"SMOKE_FIXTURE_{index}", "reviews": review})
        score([first, second], output)
        result = load(output)
        assert len(result["baseline"]) == 32 and len(result["cases"]) == 128
        assert len(result["by_condition"]) == 12
        natural = next(row for row in result["by_condition"]
                       if row["camera"] == "all" and row["condition"] == "zero")
        assert natural["hr"] == {"confirmed_offset": 31, "insufficient_landmarks": 1}
        assert natural["sr"] == {"no_confirmed_offset": 31, "insufficient_landmarks": 1}
        robust_output = Path(tmp) / "test_robust_result.json"
        score_robust([first, second], robust_output)
        robust = load(robust_output)
        assert len(robust["baseline"]) == 32 and len(robust["cases"]) == 128
        assert len(robust["summaries"]) == 12
        natural_robust = next(row for row in robust["summaries"]
                              if row["camera"] == "all" and row["condition"] == "zero")
        assert natural_robust["truth_counts"] == natural["hr"]
        assert natural_robust["counts"]["raw"] == {"missed": 31, "not_evaluable": 1}
        assert all(sum(counts.values()) == row["n"] for row in robust["summaries"]
                   for counts in row["counts"].values())
        try:
            score([first, first], output)
        except ValueError as error:
            assert "distinct reviewer IDs" in str(error)
        else:
            raise AssertionError("Duplicate reviewer was accepted")
        dump(second, {"schema": 1, "review_set": lock["review_set"], "reviewer": "SMOKE_FIXTURE_2",
                      "reviews": {"S01": b}})
        try:
            read_review(second, lock)
        except ValueError as error:
            assert "incomplete scenes" in str(error)
        else:
            raise AssertionError("Incomplete review was accepted")
    print("Artificial-coordinate smoke passed: 128 joined cases in each analysis, reliability and input checks")


if __name__ == "__main__":
    main()
